<?php

/* evabase.html.twig */
class __TwigTemplate_403889e4bcfc492fd32dc2874b7f6f2bbadfaf6f8d1e061509f79b6b1e2d25ec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btn3href' => array($this, 'block_btn3href'),
            'btn3' => array($this, 'block_btn3'),
            'btnAdicional' => array($this, 'block_btnAdicional'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html class=\"no-js\" lang=\"en\">

<head>
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title> ~ Eva |";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <!--Inclusi�n de Fuentes, tomadas de:https://www.google.com/fonts/-->
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Calligraffitti' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=sans-serif' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>

    <link rel=\"stylesheet\" href=\"http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css\">
    <link href='http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css' rel='stylesheet' type='text/css'> ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>

<body>
    <style>
        .eva {
            -webkit-box-sizing: content-box;
            -moz-box-sizing: content-box;
            box-sizing: content-box;
            border: none;
            font: normal 130px/1 \"cookie\", 'Norican', sans-serif;
            color: rgba(0, 0, 0, 1);
            -o-text-overflow: ellipsis;
            text-overflow: ellipsis;
            background: rgb(255, 255, 255);
            text-shadow: 4px 4px 6px rgba(0, 155, 255, 0.8);
            -webkit-transform: rotateX(-32.65859432245692deg) rotateY(5.156620156177409deg);
            transform: rotateX(-32.65859432245692deg) rotateY(5.156620156177409deg);
        }



        .fi-social-facebook {
            color: dodgerblue;
            font-size: 2rem;
        }

        .fi-social-youtube {
            color: red;
            font-size: 2rem;
        }

        .fi-social-twitter {
            color: skyblue;
            font-size: 2rem;
        }

        body {
            margin-top: 2rem;
        }

        .title-bar {
            background: #333;
            padding: 0.9rem;
        }

        .top-bar {
            background: #333;
        }

        .top-bar ul {
            background: #333;
        }

        .top-bar ul li {
            background: #333;
        }

        .top-bar ul li a {
            color: #fff;
        }

        .menu-text {
            color: #fff;
        }

        @media only screen and (max-width: 40em) {
            .menu-text {
                display: none !important;
            }
        }

        @media only screen and (min-width: 40em) {
            .top-bar .menu:last-child {
                border-left: 1px solid #4e4e4e;
            }
            .top-bar .menu:first-child {
                border-left: none;
            }
            .top-bar .menu li:not(:last-child) {
                border-right: 1px solid #4e4e4e;
            }
        }

        .dropdown.menu .submenu {
            border: none;
        }

        .dropdown.menu .is-dropdown-submenu-parent.is-right-arrow > a::after {
            border-color: #fff transparent transparent;
        }

        .is-drilldown-submenu-parent > a::after {
            border-color: transparent transparent transparent #fff;
        }

        .js-drilldown-back::before {
            border-color: transparent #fff transparent transparent;
        }
    </style>
    <header>
        ";
        // line 122
        echo "        <div class=\"row\">
            <div class=\"medium columns expanded text-center\">";
        // line 125
        echo "<div class=\"eva\">Eva</div>
            </div>\t
        </div>
        <br>";
        // line 129
        echo "<div class=\"title-bar\" data-responsive-toggle=\"main-menu\" data-hide-for=\"medium\">
            <button class=\"menu-icon\" type=\"button\" data-toggle></button>
            <div class=\"title-bar-title\">Menu</div>
        </div>
        <div class=\"top-bar\" id=\"main-menu\">
            <div class=\"top-bar-left\">
                <ul class=\"menu\" data-responsive-menu=\"drilldown medium-dropdown\">
                    <li><a href=\"/eva/main\" class=\"btn btn-sucess\">Página Principal</a></li>
                    <li><a href= ";
        // line 137
        $this->displayBlock('btn1href', $context, $blocks);
        echo " >";
        $this->displayBlock('btn1', $context, $blocks);
        echo "</a></li>
                    <li><a href= ";
        // line 138
        $this->displayBlock('btn2href', $context, $blocks);
        echo " class=\"btn btn-sucess\">";
        $this->displayBlock('btn2', $context, $blocks);
        echo "</a></li>
                    <li><a href= ";
        // line 139
        $this->displayBlock('btn3href', $context, $blocks);
        echo " class=\"btn btn-sucess\">";
        $this->displayBlock('btn3', $context, $blocks);
        echo "</a></li>
                    ";
        // line 140
        $this->displayBlock('btnAdicional', $context, $blocks);
        // line 141
        echo "                </ul>
            </div>
            <div class=\"top-bar-right\">
                <ul class=\"dropdown menu\" data-dropdown-menu>
                    <ul class=\"menu\">
                        <li>
                            <input type=\"search\" placeholder=\"Busquedas\">
                        </li>
                        <li>
                            <button type=\"button\" class=\"button\">Buscar</button>
                        </li>
                    </ul>
                </ul>
            </div>
        </div>";
        // line 156
        echo "</header>
    <br>
   
    <hr>
    <div class=\"row\">
        <div class=\"large-8 columns\" style=\"border-right: 1px solid #E3E5E8;\">
            ";
        // line 162
        $this->displayBlock('LeftColumn', $context, $blocks);
        // line 163
        echo "        </div>
        <div class=\"large-4 columns\">
            <aside>
                <div class=\"row column\">
                    ";
        // line 167
        $this->displayBlock('field', $context, $blocks);
        // line 168
        echo "                    <br>
                </div>
                <br>
                <hr>
                <div class=\"row small-up-3\">
                    <div class=\"column text-center\">
                        <i class=\"fi-social-facebook\"></i>
                        <a target=\"_blank\" href=\"https://www.facebook.com/GrupoLinuxUD/?fref=ts\">\tGrupo GNU/Linux UD</a>
                        <br>
                    </div>
                    <div class=\"column text-center\">
                        <i class=\"fi-social-twitter\"></i>
                        <a target=\"_blank\" href=\"https://twitter.com/grupolinuxud\">\tTwitter GLUD </a>
                        <br>
                    </div>
                    <div class=\"column text-center\">
                        <i class=\"fi-social-youtube\"></i>
                        <a target=\"_blank\" href=\"https://www.youtube.com/channel/UCWPIj_ZjOM94VRf4X2h_Kvg\">\tRadio GLUD </a>
                    </div>
                </div>

            </aside>
        </div>
    </div>
    <hr>
    <div class=\"row column\">
        <h3 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'sans-serif', cursive; font-size:28px;\t\" class=\"text-center\"> Grupo de trabajo GNU / Linux <br>Universidad Distrital Francisco José de Caldas</h3S>
    </div>
    <hr>
    <footer>
        <div class=\"ten columns\">
            \t<ul class=\"nav-bar right\">
                    <div class=\"show-for-small\" style=\"background:#FFFFFF; padding:5px;\">
                    <div style=\"width:30%; margin-right:0%; float:left;\">
                    \t<a href=\"https://glud.org/\">
                        ";
        // line 204
        echo "                       <center><div class=\"kokopelli\"><img class=\"thumbnail\" src=\"https://fbcdn-sphotos-f-a.akamaihd.net/hphotos-ak-xaf1/v/t1.0-9/13015145_1154980181208412_6240606777766531522_n.png?oh=223129eb765f354192c497bbaa32b3bd&oe=57E16126&__gda__=1469991057_acfc660301bf3d8c3eb5f21f152d23d0\" width='250' alt=\"Logotipo del GLUD\"></center></div>
                        </a>
            \t\t</div>
                    <div style=\"width:30%; margin-right:0%; float:left;\">
              \t\t\t<p style=\"margin: 0; font-family: 'sans-serif'; font-size:20px;\" class=\"text-center\"> Sede Central <br> Edificio Alejandro<br>Suárez Copete. <br> Carrera 8 No. 40 Piso 2. <br> Bogotá, Colombia </p>
                        </a>
            \t\t</div>
                    <div style=\"width:30%; float:right;\">
                    \t<a href=\"http://rita.udistrital.edu.co/ingenieria/\">
                        ";
        // line 214
        echo "                           <div class=\"UD\"><img class=\"thumbnail\" src=\"https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-xpf1/v/t1.0-9/12507117_235679856763097_6091731505178560444_n.jpg?oh=be77cc1b10f7484cbf19216d8ababa00&oe=57AEA4AF&__gda__=1474701765_e6428e0762743f003e6432d176caa322\" alt=\"image of space dog\"></div>
                        </a>
            \t\t</div>
                    <div style=\"clear:both;\"></div>
                    </div>
              \t</ul>
            </div>
    </footer>
    <script src=\"https://code.jquery.com/jquery-2.1.4.min.js\"></script>
    <script src=\"http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.js\"></script>
    <script>
        \$(document).foundation();
    </script>
    <script type=\"text/javascript\" src=\"https://intercom.zurb.com/scripts/zcom.js\"></script>
    ";
        // line 228
        $this->displayBlock('javascripts', $context, $blocks);
        // line 229
        echo "</body>
</html>
";
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
    }

    // line 137
    public function block_btn1href($context, array $blocks = array())
    {
        echo "/";
    }

    public function block_btn1($context, array $blocks = array())
    {
        echo " ";
    }

    // line 138
    public function block_btn2href($context, array $blocks = array())
    {
        echo "/";
    }

    public function block_btn2($context, array $blocks = array())
    {
        echo " ";
    }

    // line 139
    public function block_btn3href($context, array $blocks = array())
    {
        echo "/  ";
    }

    public function block_btn3($context, array $blocks = array())
    {
        echo "  ";
    }

    // line 140
    public function block_btnAdicional($context, array $blocks = array())
    {
        echo "  ";
    }

    // line 162
    public function block_LeftColumn($context, array $blocks = array())
    {
        echo " Columna Izquierda ";
    }

    // line 167
    public function block_field($context, array $blocks = array())
    {
        echo " ";
    }

    // line 228
    public function block_javascripts($context, array $blocks = array())
    {
        echo "    ";
    }

    public function getTemplateName()
    {
        return "evabase.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  362 => 228,  356 => 167,  350 => 162,  344 => 140,  333 => 139,  322 => 138,  311 => 137,  306 => 15,  301 => 7,  295 => 229,  293 => 228,  277 => 214,  266 => 204,  229 => 168,  227 => 167,  221 => 163,  219 => 162,  211 => 156,  195 => 141,  193 => 140,  187 => 139,  181 => 138,  175 => 137,  165 => 129,  160 => 125,  157 => 122,  52 => 16,  50 => 15,  39 => 7,  31 => 1,);
    }
}
/* <!doctype html>*/
/* <html class="no-js" lang="en">*/
/* */
/* <head>*/
/*     <meta charset="utf-8" />*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1.0" />*/
/*     <title> ~ Eva |{% block title %}{% endblock %}</title>*/
/*     <!--Inclusi�n de Fuentes, tomadas de:https://www.google.com/fonts/-->*/
/*     <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>*/
/*     <link href='https://fonts.googleapis.com/css?family=Calligraffitti' rel='stylesheet'>*/
/*     <link href='https://fonts.googleapis.com/css?family=sans-serif' rel='stylesheet' type='text/css'>*/
/*     <link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>*/
/* */
/*     <link rel="stylesheet" href="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">*/
/*     <link href='http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css' rel='stylesheet' type='text/css'> {% block stylesheets %}{% endblock %}*/
/*     <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/* </head>*/
/* */
/* <body>*/
/*     <style>*/
/*         .eva {*/
/*             -webkit-box-sizing: content-box;*/
/*             -moz-box-sizing: content-box;*/
/*             box-sizing: content-box;*/
/*             border: none;*/
/*             font: normal 130px/1 "cookie", 'Norican', sans-serif;*/
/*             color: rgba(0, 0, 0, 1);*/
/*             -o-text-overflow: ellipsis;*/
/*             text-overflow: ellipsis;*/
/*             background: rgb(255, 255, 255);*/
/*             text-shadow: 4px 4px 6px rgba(0, 155, 255, 0.8);*/
/*             -webkit-transform: rotateX(-32.65859432245692deg) rotateY(5.156620156177409deg);*/
/*             transform: rotateX(-32.65859432245692deg) rotateY(5.156620156177409deg);*/
/*         }*/
/* */
/* */
/* */
/*         .fi-social-facebook {*/
/*             color: dodgerblue;*/
/*             font-size: 2rem;*/
/*         }*/
/* */
/*         .fi-social-youtube {*/
/*             color: red;*/
/*             font-size: 2rem;*/
/*         }*/
/* */
/*         .fi-social-twitter {*/
/*             color: skyblue;*/
/*             font-size: 2rem;*/
/*         }*/
/* */
/*         body {*/
/*             margin-top: 2rem;*/
/*         }*/
/* */
/*         .title-bar {*/
/*             background: #333;*/
/*             padding: 0.9rem;*/
/*         }*/
/* */
/*         .top-bar {*/
/*             background: #333;*/
/*         }*/
/* */
/*         .top-bar ul {*/
/*             background: #333;*/
/*         }*/
/* */
/*         .top-bar ul li {*/
/*             background: #333;*/
/*         }*/
/* */
/*         .top-bar ul li a {*/
/*             color: #fff;*/
/*         }*/
/* */
/*         .menu-text {*/
/*             color: #fff;*/
/*         }*/
/* */
/*         @media only screen and (max-width: 40em) {*/
/*             .menu-text {*/
/*                 display: none !important;*/
/*             }*/
/*         }*/
/* */
/*         @media only screen and (min-width: 40em) {*/
/*             .top-bar .menu:last-child {*/
/*                 border-left: 1px solid #4e4e4e;*/
/*             }*/
/*             .top-bar .menu:first-child {*/
/*                 border-left: none;*/
/*             }*/
/*             .top-bar .menu li:not(:last-child) {*/
/*                 border-right: 1px solid #4e4e4e;*/
/*             }*/
/*         }*/
/* */
/*         .dropdown.menu .submenu {*/
/*             border: none;*/
/*         }*/
/* */
/*         .dropdown.menu .is-dropdown-submenu-parent.is-right-arrow > a::after {*/
/*             border-color: #fff transparent transparent;*/
/*         }*/
/* */
/*         .is-drilldown-submenu-parent > a::after {*/
/*             border-color: transparent transparent transparent #fff;*/
/*         }*/
/* */
/*         .js-drilldown-back::before {*/
/*             border-color: transparent #fff transparent transparent;*/
/*         }*/
/*     </style>*/
/*     <header>*/
/*         {#*/
/*         <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">*/
/*             <button class="menu-icon" type="button" data-toggle></button>*/
/*             <div class="title-bar-title">Menu</div>*/
/*         </div>#}*/
/*         <div class="row">*/
/*             <div class="medium columns expanded text-center">*/
/*                 {#- <img src="https://s-media-cache-ak0.pinimg.com/originals/91/34/23/913423498f0249fcf8d39f9301324e7f.png" alt="Error">-#}*/
/*                 <div class="eva">Eva</div>*/
/*             </div>	*/
/*         </div>*/
/*         <br> {#------#}*/
/*         <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">*/
/*             <button class="menu-icon" type="button" data-toggle></button>*/
/*             <div class="title-bar-title">Menu</div>*/
/*         </div>*/
/*         <div class="top-bar" id="main-menu">*/
/*             <div class="top-bar-left">*/
/*                 <ul class="menu" data-responsive-menu="drilldown medium-dropdown">*/
/*                     <li><a href="/eva/main" class="btn btn-sucess">Página Principal</a></li>*/
/*                     <li><a href= {% block btn1href %}/{% endblock %} >{% block btn1 %} {% endblock %}</a></li>*/
/*                     <li><a href= {% block btn2href %}/{% endblock %} class="btn btn-sucess">{% block btn2 %} {% endblock %}</a></li>*/
/*                     <li><a href= {% block btn3href %}/  {% endblock %} class="btn btn-sucess">{% block btn3 %}  {% endblock %}</a></li>*/
/*                     {% block btnAdicional %}  {% endblock %}*/
/*                 </ul>*/
/*             </div>*/
/*             <div class="top-bar-right">*/
/*                 <ul class="dropdown menu" data-dropdown-menu>*/
/*                     <ul class="menu">*/
/*                         <li>*/
/*                             <input type="search" placeholder="Busquedas">*/
/*                         </li>*/
/*                         <li>*/
/*                             <button type="button" class="button">Buscar</button>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </ul>*/
/*             </div>*/
/*         </div>{#--------#}*/
/*     </header>*/
/*     <br>*/
/*    */
/*     <hr>*/
/*     <div class="row">*/
/*         <div class="large-8 columns" style="border-right: 1px solid #E3E5E8;">*/
/*             {% block LeftColumn %} Columna Izquierda {% endblock %}*/
/*         </div>*/
/*         <div class="large-4 columns">*/
/*             <aside>*/
/*                 <div class="row column">*/
/*                     {% block field %} {% endblock %}*/
/*                     <br>*/
/*                 </div>*/
/*                 <br>*/
/*                 <hr>*/
/*                 <div class="row small-up-3">*/
/*                     <div class="column text-center">*/
/*                         <i class="fi-social-facebook"></i>*/
/*                         <a target="_blank" href="https://www.facebook.com/GrupoLinuxUD/?fref=ts">	Grupo GNU/Linux UD</a>*/
/*                         <br>*/
/*                     </div>*/
/*                     <div class="column text-center">*/
/*                         <i class="fi-social-twitter"></i>*/
/*                         <a target="_blank" href="https://twitter.com/grupolinuxud">	Twitter GLUD </a>*/
/*                         <br>*/
/*                     </div>*/
/*                     <div class="column text-center">*/
/*                         <i class="fi-social-youtube"></i>*/
/*                         <a target="_blank" href="https://www.youtube.com/channel/UCWPIj_ZjOM94VRf4X2h_Kvg">	Radio GLUD </a>*/
/*                     </div>*/
/*                 </div>*/
/* */
/*             </aside>*/
/*         </div>*/
/*     </div>*/
/*     <hr>*/
/*     <div class="row column">*/
/*         <h3 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'sans-serif', cursive; font-size:28px;	" class="text-center"> Grupo de trabajo GNU / Linux <br>Universidad Distrital Francisco José de Caldas</h3S>*/
/*     </div>*/
/*     <hr>*/
/*     <footer>*/
/*         <div class="ten columns">*/
/*             	<ul class="nav-bar right">*/
/*                     <div class="show-for-small" style="background:#FFFFFF; padding:5px;">*/
/*                     <div style="width:30%; margin-right:0%; float:left;">*/
/*                     	<a href="https://glud.org/">*/
/*                         {# Logo Glud #}*/
/*                        <center><div class="kokopelli"><img class="thumbnail" src="https://fbcdn-sphotos-f-a.akamaihd.net/hphotos-ak-xaf1/v/t1.0-9/13015145_1154980181208412_6240606777766531522_n.png?oh=223129eb765f354192c497bbaa32b3bd&oe=57E16126&__gda__=1469991057_acfc660301bf3d8c3eb5f21f152d23d0" width='250' alt="Logotipo del GLUD"></center></div>*/
/*                         </a>*/
/*             		</div>*/
/*                     <div style="width:30%; margin-right:0%; float:left;">*/
/*               			<p style="margin: 0; font-family: 'sans-serif'; font-size:20px;" class="text-center"> Sede Central <br> Edificio Alejandro<br>Suárez Copete. <br> Carrera 8 No. 40 Piso 2. <br> Bogotá, Colombia </p>*/
/*                         </a>*/
/*             		</div>*/
/*                     <div style="width:30%; float:right;">*/
/*                     	<a href="http://rita.udistrital.edu.co/ingenieria/">*/
/*                         {# Logo UD #}*/
/*                            <div class="UD"><img class="thumbnail" src="https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-xpf1/v/t1.0-9/12507117_235679856763097_6091731505178560444_n.jpg?oh=be77cc1b10f7484cbf19216d8ababa00&oe=57AEA4AF&__gda__=1474701765_e6428e0762743f003e6432d176caa322" alt="image of space dog"></div>*/
/*                         </a>*/
/*             		</div>*/
/*                     <div style="clear:both;"></div>*/
/*                     </div>*/
/*               	</ul>*/
/*             </div>*/
/*     </footer>*/
/*     <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>*/
/*     <script src="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.js"></script>*/
/*     <script>*/
/*         $(document).foundation();*/
/*     </script>*/
/*     <script type="text/javascript" src="https://intercom.zurb.com/scripts/zcom.js"></script>*/
/*     {% block javascripts %}    {% endblock %}*/
/* </body>*/
/* </html>*/
/* */
