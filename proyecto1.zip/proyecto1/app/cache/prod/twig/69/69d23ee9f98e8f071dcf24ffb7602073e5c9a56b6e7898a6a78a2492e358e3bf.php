<?php

/* :eva:docente.html.twig */
class __TwigTemplate_df0f8c43ddfb193dbd4e8cff9eff6f12745eeabafd1948198635210d7f220714 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", ":eva:docente.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'field' => array($this, 'block_field'),
            'field1' => array($this, 'block_field1'),
            'field2' => array($this, 'block_field2'),
            'field3' => array($this, 'block_field3'),
            'field4' => array($this, 'block_field4'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btn3href' => array($this, 'block_btn3href'),
            'btn3' => array($this, 'block_btn3'),
            'subtitle' => array($this, 'block_subtitle'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Docente";
    }

    // line 3
    public function block_titulo($context, array $blocks = array())
    {
        $this->displayParentBlock("titulo", $context, $blocks);
    }

    // line 4
    public function block_field($context, array $blocks = array())
    {
    }

    // line 6
    public function block_field1($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
    }

    // line 11
    public function block_field2($context, array $blocks = array())
    {
        // line 12
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
    }

    // line 16
    public function block_field3($context, array $blocks = array())
    {
        // line 17
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
    }

    // line 21
    public function block_field4($context, array $blocks = array())
    {
        // line 22
        echo "    <img style=\"max-width:100px; max-height:100px;\" class=\"thumbnail\" src=\"https://upload.wikimedia.org/wikipedia/commons/3/35/Tux.svg\">
    Linux
";
    }

    // line 25
    public function block_LeftColumn($context, array $blocks = array())
    {
        // line 26
        echo "    Porfavor, seleccione alguna de las opciones presentadas en la parte superior.
    <link href=\"http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css\" rel=\"stylesheet\">
";
    }

    // line 30
    public function block_btn1href($context, array $blocks = array())
    {
        // line 31
        echo "    /ListaExamenes
";
    }

    // line 33
    public function block_btn1($context, array $blocks = array())
    {
        echo "Examenes Creados
";
    }

    // line 36
    public function block_btn2href($context, array $blocks = array())
    {
        // line 37
        echo "    /createExam
";
    }

    // line 39
    public function block_btn2($context, array $blocks = array())
    {
        // line 40
        echo "    Crear Examen";
    }

    // line 42
    public function block_btn3href($context, array $blocks = array())
    {
    }

    // line 43
    public function block_btn3($context, array $blocks = array())
    {
        echo "Añadir Estudiante
";
    }

    // line 45
    public function block_subtitle($context, array $blocks = array())
    {
    }

    // line 47
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 48
        echo "    <style>
        .log-in-form {
            border: 1px solid #cacaca;
            padding: 1rem;
            border-radius: 3px;
        }
        .header {
            text-align: center;
            background: #000000;
            background-size: cover;
            padding: 4rem;
        }
        .header .main-header {
            color: #666;
        }

        .header-subnav {
            float: none;
            position: relative;
            top: 4rem;
            text-align: center;
            margin-bottom: 0;
        }
        .header-subnav li {
            float: none;
            display: inline-block;
        }
        .header-subnav li a {
            padding: 0.9rem 1rem 0.75rem;
            font-size: 0.875rem;
            color: #fff;
            text-transform: uppercase;
            display: block;
            font-weight: bold;
            letter-spacing: 1px;
        }
        .header-subnav li a.is-active {
            background: rgba(250, 250, 250, 0.7);
            color: #333;
        }
        .header-subnav li a:hover {
            background: rgba(250, 250, 250, 0.7);
            color: #333;
            transition: all 0.25s ease-in-out;
        }

    </style>
";
    }

    public function getTemplateName()
    {
        return ":eva:docente.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 48,  155 => 47,  150 => 45,  143 => 43,  138 => 42,  134 => 40,  131 => 39,  126 => 37,  123 => 36,  116 => 33,  111 => 31,  108 => 30,  102 => 26,  99 => 25,  93 => 22,  90 => 21,  83 => 17,  80 => 16,  73 => 12,  70 => 11,  63 => 7,  60 => 6,  55 => 4,  49 => 3,  43 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}Docente{% endblock %}{#Titulo barra navegador#}*/
/* {% block titulo %}{{parent()}}{% endblock %}{#Titulo interno página#}*/
/* {% block field %}{% endblock %}{#Primer Texto Columna Izq#}*/
/* {#  Adición de imagenes por campo en la plantilla #}*/
/* {% block field1 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field2 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field3 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field4 %}*/
/*     <img style="max-width:100px; max-height:100px;" class="thumbnail" src="https://upload.wikimedia.org/wikipedia/commons/3/35/Tux.svg">*/
/*     Linux*/
/* {% endblock %}*/
/* {% block LeftColumn %}*/
/*     Porfavor, seleccione alguna de las opciones presentadas en la parte superior.*/
/*     <link href="http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css" rel="stylesheet">*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /ListaExamenes*/
/* {% endblock %}*/
/* {% block btn1 %}Examenes Creados*/
/* {% endblock %}*/
/* */
/* {% block btn2href %}*/
/*     /createExam*/
/* {% endblock %}*/
/* {% block btn2 %}*/
/*     Crear Examen{% endblock %}*/
/* */
/* {% block btn3href %}{% endblock %}*/
/* {% block btn3 %}Añadir Estudiante*/
/* {% endblock %}*/
/* {% block subtitle %}{% endblock %}*/
/* */
/* {% block stylesheets %}*/
/*     <style>*/
/*         .log-in-form {*/
/*             border: 1px solid #cacaca;*/
/*             padding: 1rem;*/
/*             border-radius: 3px;*/
/*         }*/
/*         .header {*/
/*             text-align: center;*/
/*             background: #000000;*/
/*             background-size: cover;*/
/*             padding: 4rem;*/
/*         }*/
/*         .header .main-header {*/
/*             color: #666;*/
/*         }*/
/* */
/*         .header-subnav {*/
/*             float: none;*/
/*             position: relative;*/
/*             top: 4rem;*/
/*             text-align: center;*/
/*             margin-bottom: 0;*/
/*         }*/
/*         .header-subnav li {*/
/*             float: none;*/
/*             display: inline-block;*/
/*         }*/
/*         .header-subnav li a {*/
/*             padding: 0.9rem 1rem 0.75rem;*/
/*             font-size: 0.875rem;*/
/*             color: #fff;*/
/*             text-transform: uppercase;*/
/*             display: block;*/
/*             font-weight: bold;*/
/*             letter-spacing: 1px;*/
/*         }*/
/*         .header-subnav li a.is-active {*/
/*             background: rgba(250, 250, 250, 0.7);*/
/*             color: #333;*/
/*         }*/
/*         .header-subnav li a:hover {*/
/*             background: rgba(250, 250, 250, 0.7);*/
/*             color: #333;*/
/*             transition: all 0.25s ease-in-out;*/
/*         }*/
/* */
/*     </style>*/
/* {% endblock %}*/
/* */
