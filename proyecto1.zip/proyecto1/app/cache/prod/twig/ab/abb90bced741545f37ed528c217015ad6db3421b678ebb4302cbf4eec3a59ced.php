<?php

/* :eva:createExam.html.twig */
class __TwigTemplate_c4d783c1f3c795371f8a39f0f8d5543f08985f90aae28072d6c9db80df7300fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", ":eva:createExam.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btnAdicional' => array($this, 'block_btnAdicional'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "    createExam!";
    }

    // line 6
    public function block_titulo($context, array $blocks = array())
    {
        $this->displayParentBlock("titulo", $context, $blocks);
    }

    // line 8
    public function block_btn1href($context, array $blocks = array())
    {
        // line 9
        echo "    /docente
";
    }

    // line 11
    public function block_btn1($context, array $blocks = array())
    {
        // line 12
        echo "    Salir Sin Guardar";
    }

    // line 13
    public function block_btn2href($context, array $blocks = array())
    {
    }

    // line 14
    public function block_btn2($context, array $blocks = array())
    {
        echo "Guardar Examen";
    }

    // line 16
    public function block_btnAdicional($context, array $blocks = array())
    {
        // line 17
        echo "    <li class=\"has-submenu\">
        <a href=\"#\">
            Añadir Pregunta
        </a>
        <ul class=\"submenu menu vertical\" data-submenu>
        <li>
            <a href=\"#\">Pregunta para Adjuntar Archivo</a>
        </li>
        <li>
            <a href=\"#\">Pregunta Abierta</a>
        </li>
        <li>
            <a href=\"#\">Pregunta de Selección múltiple con múltiple Respuesta</a>
        </li>
        <li>
            <a href=\"#\">Pregunta de Falso o Verdadero</a>
        </li>
        <li>
            <a href=\"#\">Pregunta para Unir</a>
        </li>
        <li>
            <a href=\"#\"></a>
        </li>
    </ul>
</li>
";
    }

    // line 43
    public function block_LeftColumn($context, array $blocks = array())
    {
        // line 44
        echo "
<div class=\"callout\">
    <h5>
        (1).<textarea
            title=\"Porfavor, Ingrese la pregunta en este espacio\"
            class=\"uiTextareaAutogrow _3en1\"
            name=\"xhpc_message\"
            placeholder=\"Porfavor, Ingrese la pregunta en este espacio\"
            onkeydown=\"run_with(this, [&quot;legacy:control-textarea&quot;], function() &#123;TextAreaControl.getInstance(this)&#125;);\"></textarea>
    </h5>
    <ul class=\"button-group round even-8\">
        <li>
            <a href=\"#\" class=\"button\">Añadir Opción</a>
        </li>
        <form method=\"get\" action=\"http://aprenderaprogramar.com/action.php\">
       <br />
       <br />
       <input name=\"intereses\" type=\"radio\" value=\"rbiinternet\" checked=\"checked\" />OpciónUno

       </form>

_________________________________________________________________________________________----
        <li>
            <a href=\"#\" class=\"button\">Seleccionar Respuesta</a>
        </li>
        <li>
            <a href=\"#\" class=\"button\">Guardar</a>
        </li>
        <li>
            <a href=\"#\" class=\"button\">Eliminar</a>
        </li>
    </ul>
</div>

";
    }

    // line 80
    public function block_field($context, array $blocks = array())
    {
        // line 81
        echo "Porfavor, adicione una pregunta.
<div class=\"large-4 columns\">
    <h4>-</h4>
    <a href=\"#\" data-reveal-id=\"firstModal\" class=\"radius button\">Question…</a>

    <div style=\"display: none;\"></div>

    <div style=\"display: none; opacity: 1; visibility: hidden; top: 842px;\" id=\"secondModal\" class=\"reveal-modal\" data-reveal=\"\" aria-labelledby=\"secondModalTitle\" aria-hidden=\"true\" role=\"dialog\">
        <h2 id=\"secondModalTitle\">This is a second modal.</h2>
        <p>See? It just slides into place after the other first modal. Very handy when you need subsequent dialogs, or when a modal option impacts or requires another decision.</p>
        <a class=\"close-reveal-modal\" aria-label=\"Close\">×</a>
    </div>

</div>
";
    }

    public function getTemplateName()
    {
        return ":eva:createExam.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 81,  148 => 80,  110 => 44,  107 => 43,  78 => 17,  75 => 16,  69 => 14,  64 => 13,  60 => 12,  57 => 11,  52 => 9,  49 => 8,  43 => 6,  39 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* */
/* {% block title %}*/
/*     createExam!{% endblock %}*/
/* */
/* {% block titulo %}{{parent()}}{% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /docente*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir Sin Guardar{% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}Guardar Examen{% endblock %}*/
/* */
/* {% block btnAdicional %}*/
/*     <li class="has-submenu">*/
/*         <a href="#">*/
/*             Añadir Pregunta*/
/*         </a>*/
/*         <ul class="submenu menu vertical" data-submenu>*/
/*         <li>*/
/*             <a href="#">Pregunta para Adjuntar Archivo</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#">Pregunta Abierta</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#">Pregunta de Selección múltiple con múltiple Respuesta</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#">Pregunta de Falso o Verdadero</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#">Pregunta para Unir</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#"></a>*/
/*         </li>*/
/*     </ul>*/
/* </li>*/
/* {% endblock %}*/
/* {% block LeftColumn %}*/
/* */
/* <div class="callout">*/
/*     <h5>*/
/*         (1).<textarea*/
/*             title="Porfavor, Ingrese la pregunta en este espacio"*/
/*             class="uiTextareaAutogrow _3en1"*/
/*             name="xhpc_message"*/
/*             placeholder="Porfavor, Ingrese la pregunta en este espacio"*/
/*             onkeydown="run_with(this, [&quot;legacy:control-textarea&quot;], function() &#123;TextAreaControl.getInstance(this)&#125;);"></textarea>*/
/*     </h5>*/
/*     <ul class="button-group round even-8">*/
/*         <li>*/
/*             <a href="#" class="button">Añadir Opción</a>*/
/*         </li>*/
/*         <form method="get" action="http://aprenderaprogramar.com/action.php">*/
/*        <br />*/
/*        <br />*/
/*        <input name="intereses" type="radio" value="rbiinternet" checked="checked" />OpciónUno*/
/* */
/*        </form>*/
/* */
/* _________________________________________________________________________________________----*/
/*         <li>*/
/*             <a href="#" class="button">Seleccionar Respuesta</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#" class="button">Guardar</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#" class="button">Eliminar</a>*/
/*         </li>*/
/*     </ul>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block field %}*/
/* Porfavor, adicione una pregunta.*/
/* <div class="large-4 columns">*/
/*     <h4>-</h4>*/
/*     <a href="#" data-reveal-id="firstModal" class="radius button">Question…</a>*/
/* */
/*     <div style="display: none;"></div>*/
/* */
/*     <div style="display: none; opacity: 1; visibility: hidden; top: 842px;" id="secondModal" class="reveal-modal" data-reveal="" aria-labelledby="secondModalTitle" aria-hidden="true" role="dialog">*/
/*         <h2 id="secondModalTitle">This is a second modal.</h2>*/
/*         <p>See? It just slides into place after the other first modal. Very handy when you need subsequent dialogs, or when a modal option impacts or requires another decision.</p>*/
/*         <a class="close-reveal-modal" aria-label="Close">×</a>*/
/*     </div>*/
/* */
/* </div>*/
/* {% endblock %}*/
/* */
