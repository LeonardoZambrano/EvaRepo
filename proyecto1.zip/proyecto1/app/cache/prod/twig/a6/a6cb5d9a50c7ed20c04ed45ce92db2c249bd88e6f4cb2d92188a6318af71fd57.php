<?php

/* :eva:estudiante.html.twig */
class __TwigTemplate_ad33e3621d23d9440b1d129e453bcd63a59939b281f312d889faef664ed12e44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", ":eva:estudiante.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        // line 3
        echo "    Examenes Creados";
    }

    // line 5
    public function block_titulo($context, array $blocks = array())
    {
        // line 6
        echo "    Cursos...
    ";
    }

    // line 10
    public function block_btn1href($context, array $blocks = array())
    {
        // line 11
        echo "    /main
";
    }

    // line 13
    public function block_btn1($context, array $blocks = array())
    {
        // line 14
        echo "    Salir
";
    }

    // line 16
    public function block_btn2href($context, array $blocks = array())
    {
    }

    // line 17
    public function block_btn2($context, array $blocks = array())
    {
    }

    // line 19
    public function block_LeftColumn($context, array $blocks = array())
    {
        // line 20
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;\t\">
            Primer Curso Inscrito</h5>
        <p>
            Docente: _______<br>
            Email: ____________

        </p>
        <div class=\"button-group\">
          ";
        // line 30
        echo "          <a href=\"/presentarExam\" type=\"submit\" class=\"success button\"> Presentar Examen </a>

            <a class=\"warning button\">Editar</a>
            <a class=\"alert button\">Abandonar Curso</a>
        </div>
    </div>
";
    }

    // line 38
    public function block_field($context, array $blocks = array())
    {
        // line 39
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;\t\">
            Cursos Disponibles</h5>
        <p>
            Añadir Tabla:
        </p>
        <div class=\"cursoUno\">

        <button class=\"hollow button\" href=\"#\">
            Inscribir</button>
            Docente: _____  Información acerca del curso
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return ":eva:estudiante.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 39,  100 => 38,  90 => 30,  79 => 20,  76 => 19,  71 => 17,  66 => 16,  61 => 14,  58 => 13,  53 => 11,  50 => 10,  45 => 6,  42 => 5,  38 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}*/
/*     Examenes Creados{% endblock %}*/
/* */
/* {% block titulo %}*/
/*     Cursos...*/
/*     {#Añadir Nombre Curso#}*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /main*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir*/
/* {% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}{% endblock %}*/
/* */
/* {% block LeftColumn %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;	">*/
/*             Primer Curso Inscrito</h5>*/
/*         <p>*/
/*             Docente: _______<br>*/
/*             Email: ____________*/
/* */
/*         </p>*/
/*         <div class="button-group">*/
/*           {# <a class="secondary button">Asignar Hora Examen</a>#}*/
/*           <a href="/presentarExam" type="submit" class="success button"> Presentar Examen </a>*/
/* */
/*             <a class="warning button">Editar</a>*/
/*             <a class="alert button">Abandonar Curso</a>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block field %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;	">*/
/*             Cursos Disponibles</h5>*/
/*         <p>*/
/*             Añadir Tabla:*/
/*         </p>*/
/*         <div class="cursoUno">*/
/* */
/*         <button class="hollow button" href="#">*/
/*             Inscribir</button>*/
/*             Docente: _____  Información acerca del curso*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
