<?php

/* :eva:invitado.html.twig */
class __TwigTemplate_b6dff175b0d9b8588a2c38568701ce64771cdbe71717f6aeab6489e2fb0e58f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", ":eva:invitado.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Cursos ";
    }

    // line 3
    public function block_LeftColumn($context, array $blocks = array())
    {
        // line 4
        echo "
";
    }

    public function getTemplateName()
    {
        return ":eva:invitado.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 4,  35 => 3,  29 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}Cursos {% endblock %}*/
/* {% block LeftColumn %}*/
/* */
/* {% endblock %}*/
/* */
