<?php

/* :eva:index.html.twig */
class __TwigTemplate_bad77e3c73f169d6333b565f5621badf71d8b524bef357d277a92e4d34ccb0b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", ":eva:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'field' => array($this, 'block_field'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Bienvenidos!";
    }

    // line 3
    public function block_titulo($context, array $blocks = array())
    {
        $this->displayParentBlock("titulo", $context, $blocks);
    }

    // line 6
    public function block_btn1href($context, array $blocks = array())
    {
        echo " /eva/student";
    }

    public function block_btn1($context, array $blocks = array())
    {
        echo " estudiante ";
    }

    // line 8
    public function block_field($context, array $blocks = array())
    {
        $this->displayParentBlock("field", $context, $blocks);
        echo "

";
        // line 11
        echo "<div class=\"row column\">
    <form>
                <div class=\"row column log-in-form\">
                    <h4 class=\"text-center\">Regístrate</h4>
                    <label>Nombres
                        <input type=\"text\" placeholder=\"GNU\">
                    </label>
                    <label>Apellidos
                        <input type=\"text\" placeholder=\"Linux\">
                    </label>
                    <label>Correo electrónico 
                        <input type=\"text\" placeholder=\"somebody@example.com\">
                    </label>
                    <div class=\"row field\">
                        <div class=\"small-12 columns\">
                            <label for=\"field_15\">
                                Rol
                            </label>
                            <select name=\"field_15\" id=\"field_15\">
                                <option selected=\"selected\" value=\"blank\"></option>
                                <option value=\"Teacher\">Docente</option>
                                <option value=\"Student\">Estudiante</option>
                            </select>
                        </div>
                        <!--<div class=\"small-12 columns\">
                        <div class=\"tooltip-container\" id=\"tooltip-box-title_tooltip\"><a href=\"javascript:void()\">?</a></div>                                                                </div>-->
                    </div>
                    <p>

                        <a href=alert(\"Enviado\"); type=\"submit\" class=\"button expanded\">Enviar!</a>
                    </p>
                </div>
            </form>
</div>


";
    }

    // line 48
    public function block_LeftColumn($context, array $blocks = array())
    {
        // line 49
        echo "    <div class=\"row\">
        <div class=\"small-5 columns\">
            <form>
                <div class=\"row column log-in-form\">
                    <h4 class=\"text-center\">Sistema de acceso</h4>
                    <label>Correo electrónico
                        <input type=\"text\" placeholder=\"somebody@example.com\">
                    </label>
                    <label>Contraseña
                        <input type=\"text\" placeholder=\"Password\">
                    </label>
                    <input id=\"show-password\" type=\"checkbox\">
                    <label for=\"show-password\">Mostrar contraseña</label>
                    <p>
                        <a href=\"/docente\" type=\"submit\" class=\"button expanded\"> Iniciar sesión </a>

                        <a href=\"/invitado\" type=\"submit\" class=\"button expanded\">Inicie la sesión como invitado</a>
                    </p>
                    <p class=\"text-center\">
                        <a href=\"#\">¿Olvido su contraseña?</a>
                    </p>
                </div>
            </form>
        </div>
        <div class=\"small-7 columns text-center\">
            <div style=\"background:rgba(0,155,255, 0.8);
                color: #FFFFFF ;
                width:100%;
                padding:30px;
                border:10px solid #FFFFFF;
                font-family: 'sans-serif'; font-size:20px;  font-weight:bold;\t\"class=\"property-info-center\">
               <p><a style=\"font-family: 'sans-serif'; font-size:26px; color: #000000 ;\"href=\"https://gludblog.wordpress.com/\">¿Que es EVA?</a>
               <p>Eva es un Sistema de Calificación desarrollado por el Grupo de trabajo GNU/Linux Universidad Distrital Francisco José de Caldas</p>
               <p><a style=\"font-family: 'sans-serif'; font-size:26px; color: #000000 ;\"href=\"https://gludblog.wordpress.com/\">www.glud.org</a>
                </p>
            </div>
        </div>
    </div>
  <br>
    <div class=\"row\">
        <div class=\"large-6 columns\">
            <!--Calendar-->
            <h4 class=\"section-title\" style=\"margin-bottom: 0px; padding-top: 3px;\">
                Fecha:
                <script>
  var mydate=new Date();
  var year=mydate.getYear();
  if (year < 1000)
  year+=1900;
  var day=mydate.getDay();
  var month=mydate.getMonth()+1;
  if (month<10)
  month=\"0\"+month;
  var daym=mydate.getDate();
  if (daym<10)
  daym=\"0\"+daym;
  if(month==5){
  month=\"May\";
  }
  if(month==6){
  month=\"June\";
  }
  document.write(\"<small><font color='000000' face='sans-serif'><b>\"+daym+\" / \"+month+\" / \"+year+\"</b></font></small>\")

  </script>
            </h4>
            <br>
            <div id=\"calendar\">
                <div style=\"clear: both;\" align=\"left\">
                <table width=\"50\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" summary=\"Monthly calendar with links to each days posts\">
                    <caption class=\"calendar-date\">May 2016</caption>
                    <tr class=\"calendar-day\">
                        <th class=\"cal-2\" abbr=\"Sunday\" align=\"center\">S</th>
                        <th class=\"cal-1\" abbr=\"Monday\" align=\"center\">M</th>
                        <th class=\"cal-2\" abbr=\"Tuesday\" align=\"center\">T</th>
                        <th class=\"cal-1\" abbr=\"Wednesday\" align=\"center\">W</th>
                        <th class=\"cal-2\" abbr=\"Thursday\" align=\"center\">T</th>
                        <th class=\"cal-1\" abbr=\"Friday\" align=\"center\">F</th>
                        <th class=\"cal-2\" abbr=\"Saturday\" align=\"center\">S</th>
                    </tr>
                    <tr>
                        <td class=\"cal-2\">   1   </td>
                        <td class=\"cal-1\">   2   </td>
                        <td class=\"cal-2\">   3   </td>
                        <td class=\"cal-1\">   4   </td>
                        <td class=\"cal-2\">   5   </td>
                        <td class=\"cal-1\">   6   </td>
                        <td class=\"cal-2\">   7   </td>
                    </tr>
                    <tr>
                        <td class=\"cal-2\">   8     </td>
                        <td class=\"cal-1\">      9                           </td>
                        <td class=\"cal-2\">      <div class=\"today\">10</div>              </td>
                        <td class=\"cal-1\">      11                          </td>
                        <td class=\"cal-2\">      12                          </td>
                        <td class=\"cal-1\">      13                          </td>
                        <td class=\"cal-2\">      14                          </td>
                    </tr>
                    <tr>
                        <td class=\"cal-2\">      15                          </td>
                        <td class=\"cal-1\">      16                          </td>
                        <td class=\"cal-2\">      17                          </td>
                        <td class=\"cal-1\">      18                          </td>
                        <td class=\"cal-2\">      19                          </td>
                        <td class=\"cal-1\">      20                          </td>
                        <td class=\"cal-2\">      21                          </td>
                    </tr>
                    <tr>
                        <td class=\"cal-2\">      22                          </td>
                        <td class=\"cal-1\">      23                          </td>
                        <td class=\"cal-2\">      24                          </td>
                        <td class=\"cal-1\">      25                          </td>
                        <td class=\"cal-2\">      26                          </td>
                        <td class=\"cal-1\">      27                          </td>
                        <td class=\"cal-2\">      28                          </td>
                    </tr>
                    <tr>
                        <td class=\"cal-2\">      29                        </td>
                        <td class=\"cal-1\">      30                        </td>
                        <td class=\"cal-2\">      31                        </td>
                        <td class=\"cal-1\"></td>
                        <td class=\"cal-2\"></td>
                        <td class=\"cal-1\"></td>
                        <td class=\"cal-2\"></td>
                    </tr>
                </table>
                </div>
            </div>
        </div>
    <div class=\"small-6 columns\">
    <div class=\"media-object\">
        <div class=\"media-object-section\">
            <h5>Primera Imagen</h5>
            <img class=\"thumbnail\" src=\"http://placehold.it/100\">
            <img class=\"thumbnail\" src=\"http://placehold.it/100\">
            <img class=\"thumbnail\" src=\"http://placehold.it/100\">
        </div>
    </div>
    <div class=\"media-object\">
        <div class=\"media-object-section\">
            <h5>Segunda Imagen</h5>
            <img class=\"thumbnail\" src=\"http://placehold.it/100\">
            <img class=\"thumbnail\" src=\"http://placehold.it/100\">
            <img class=\"thumbnail\" src=\"http://placehold.it/100\">
        </div>
    </div>
        </div>
    </div>
    <hr>

";
    }

    // line 200
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 201
        echo "    <style>
        .log-in-form {
            border: 1px solid #cacaca;
            padding: 1rem;
            border-radius: 3px;
        }
    </style>
";
    }

    public function getTemplateName()
    {
        return ":eva:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  264 => 201,  261 => 200,  107 => 49,  104 => 48,  64 => 11,  57 => 8,  46 => 6,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}Bienvenidos!{% endblock %}{#Titulo barra navegador#}*/
/* {% block titulo %}{{parent()}}{% endblock %}{#Titulo interno página#}*/
/* */
/* {#Btones #}*/
/* {% block btn1href %} /eva/student{% endblock %} {% block btn1 %} estudiante {% endblock %}*/
/* */
/* {% block field %}{{parent()}}*/
/* */
/* {#  Adición de imagenes por campo en la plantilla #}*/
/* <div class="row column">*/
/*     <form>*/
/*                 <div class="row column log-in-form">*/
/*                     <h4 class="text-center">Regístrate</h4>*/
/*                     <label>Nombres*/
/*                         <input type="text" placeholder="GNU">*/
/*                     </label>*/
/*                     <label>Apellidos*/
/*                         <input type="text" placeholder="Linux">*/
/*                     </label>*/
/*                     <label>Correo electrónico */
/*                         <input type="text" placeholder="somebody@example.com">*/
/*                     </label>*/
/*                     <div class="row field">*/
/*                         <div class="small-12 columns">*/
/*                             <label for="field_15">*/
/*                                 Rol*/
/*                             </label>*/
/*                             <select name="field_15" id="field_15">*/
/*                                 <option selected="selected" value="blank"></option>*/
/*                                 <option value="Teacher">Docente</option>*/
/*                                 <option value="Student">Estudiante</option>*/
/*                             </select>*/
/*                         </div>*/
/*                         <!--<div class="small-12 columns">*/
/*                         <div class="tooltip-container" id="tooltip-box-title_tooltip"><a href="javascript:void()">?</a></div>                                                                </div>-->*/
/*                     </div>*/
/*                     <p>*/
/* */
/*                         <a href=alert("Enviado"); type="submit" class="button expanded">Enviar!</a>*/
/*                     </p>*/
/*                 </div>*/
/*             </form>*/
/* </div>*/
/* */
/* */
/* {% endblock %}{#Primer Texto Columna Izq#}*/
/* {% block LeftColumn %}*/
/*     <div class="row">*/
/*         <div class="small-5 columns">*/
/*             <form>*/
/*                 <div class="row column log-in-form">*/
/*                     <h4 class="text-center">Sistema de acceso</h4>*/
/*                     <label>Correo electrónico*/
/*                         <input type="text" placeholder="somebody@example.com">*/
/*                     </label>*/
/*                     <label>Contraseña*/
/*                         <input type="text" placeholder="Password">*/
/*                     </label>*/
/*                     <input id="show-password" type="checkbox">*/
/*                     <label for="show-password">Mostrar contraseña</label>*/
/*                     <p>*/
/*                         <a href="/docente" type="submit" class="button expanded"> Iniciar sesión </a>*/
/* */
/*                         <a href="/invitado" type="submit" class="button expanded">Inicie la sesión como invitado</a>*/
/*                     </p>*/
/*                     <p class="text-center">*/
/*                         <a href="#">¿Olvido su contraseña?</a>*/
/*                     </p>*/
/*                 </div>*/
/*             </form>*/
/*         </div>*/
/*         <div class="small-7 columns text-center">*/
/*             <div style="background:rgba(0,155,255, 0.8);*/
/*                 color: #FFFFFF ;*/
/*                 width:100%;*/
/*                 padding:30px;*/
/*                 border:10px solid #FFFFFF;*/
/*                 font-family: 'sans-serif'; font-size:20px;  font-weight:bold;	"class="property-info-center">*/
/*                <p><a style="font-family: 'sans-serif'; font-size:26px; color: #000000 ;"href="https://gludblog.wordpress.com/">¿Que es EVA?</a>*/
/*                <p>Eva es un Sistema de Calificación desarrollado por el Grupo de trabajo GNU/Linux Universidad Distrital Francisco José de Caldas</p>*/
/*                <p><a style="font-family: 'sans-serif'; font-size:26px; color: #000000 ;"href="https://gludblog.wordpress.com/">www.glud.org</a>*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/*   <br>*/
/*     <div class="row">*/
/*         <div class="large-6 columns">*/
/*             <!--Calendar-->*/
/*             <h4 class="section-title" style="margin-bottom: 0px; padding-top: 3px;">*/
/*                 Fecha:*/
/*                 <script>*/
/*   var mydate=new Date();*/
/*   var year=mydate.getYear();*/
/*   if (year < 1000)*/
/*   year+=1900;*/
/*   var day=mydate.getDay();*/
/*   var month=mydate.getMonth()+1;*/
/*   if (month<10)*/
/*   month="0"+month;*/
/*   var daym=mydate.getDate();*/
/*   if (daym<10)*/
/*   daym="0"+daym;*/
/*   if(month==5){*/
/*   month="May";*/
/*   }*/
/*   if(month==6){*/
/*   month="June";*/
/*   }*/
/*   document.write("<small><font color='000000' face='sans-serif'><b>"+daym+" / "+month+" / "+year+"</b></font></small>")*/
/* */
/*   </script>*/
/*             </h4>*/
/*             <br>*/
/*             <div id="calendar">*/
/*                 <div style="clear: both;" align="left">*/
/*                 <table width="50" border="0" cellspacing="0" cellpadding="0" summary="Monthly calendar with links to each days posts">*/
/*                     <caption class="calendar-date">May 2016</caption>*/
/*                     <tr class="calendar-day">*/
/*                         <th class="cal-2" abbr="Sunday" align="center">S</th>*/
/*                         <th class="cal-1" abbr="Monday" align="center">M</th>*/
/*                         <th class="cal-2" abbr="Tuesday" align="center">T</th>*/
/*                         <th class="cal-1" abbr="Wednesday" align="center">W</th>*/
/*                         <th class="cal-2" abbr="Thursday" align="center">T</th>*/
/*                         <th class="cal-1" abbr="Friday" align="center">F</th>*/
/*                         <th class="cal-2" abbr="Saturday" align="center">S</th>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td class="cal-2">   1   </td>*/
/*                         <td class="cal-1">   2   </td>*/
/*                         <td class="cal-2">   3   </td>*/
/*                         <td class="cal-1">   4   </td>*/
/*                         <td class="cal-2">   5   </td>*/
/*                         <td class="cal-1">   6   </td>*/
/*                         <td class="cal-2">   7   </td>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td class="cal-2">   8     </td>*/
/*                         <td class="cal-1">      9                           </td>*/
/*                         <td class="cal-2">      <div class="today">10</div>              </td>*/
/*                         <td class="cal-1">      11                          </td>*/
/*                         <td class="cal-2">      12                          </td>*/
/*                         <td class="cal-1">      13                          </td>*/
/*                         <td class="cal-2">      14                          </td>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td class="cal-2">      15                          </td>*/
/*                         <td class="cal-1">      16                          </td>*/
/*                         <td class="cal-2">      17                          </td>*/
/*                         <td class="cal-1">      18                          </td>*/
/*                         <td class="cal-2">      19                          </td>*/
/*                         <td class="cal-1">      20                          </td>*/
/*                         <td class="cal-2">      21                          </td>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td class="cal-2">      22                          </td>*/
/*                         <td class="cal-1">      23                          </td>*/
/*                         <td class="cal-2">      24                          </td>*/
/*                         <td class="cal-1">      25                          </td>*/
/*                         <td class="cal-2">      26                          </td>*/
/*                         <td class="cal-1">      27                          </td>*/
/*                         <td class="cal-2">      28                          </td>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td class="cal-2">      29                        </td>*/
/*                         <td class="cal-1">      30                        </td>*/
/*                         <td class="cal-2">      31                        </td>*/
/*                         <td class="cal-1"></td>*/
/*                         <td class="cal-2"></td>*/
/*                         <td class="cal-1"></td>*/
/*                         <td class="cal-2"></td>*/
/*                     </tr>*/
/*                 </table>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     <div class="small-6 columns">*/
/*     <div class="media-object">*/
/*         <div class="media-object-section">*/
/*             <h5>Primera Imagen</h5>*/
/*             <img class="thumbnail" src="http://placehold.it/100">*/
/*             <img class="thumbnail" src="http://placehold.it/100">*/
/*             <img class="thumbnail" src="http://placehold.it/100">*/
/*         </div>*/
/*     </div>*/
/*     <div class="media-object">*/
/*         <div class="media-object-section">*/
/*             <h5>Segunda Imagen</h5>*/
/*             <img class="thumbnail" src="http://placehold.it/100">*/
/*             <img class="thumbnail" src="http://placehold.it/100">*/
/*             <img class="thumbnail" src="http://placehold.it/100">*/
/*         </div>*/
/*     </div>*/
/*         </div>*/
/*     </div>*/
/*     <hr>*/
/* */
/* {% endblock %}*/
/* {% block stylesheets %}*/
/*     <style>*/
/*         .log-in-form {*/
/*             border: 1px solid #cacaca;*/
/*             padding: 1rem;*/
/*             border-radius: 3px;*/
/*         }*/
/*     </style>*/
/* {% endblock %}*/
/* */
