<?php

/* :eva:ListaExamenes.html.twig */
class __TwigTemplate_176e1c886e4cf5cea43129718c0d72c8e652751d0392e3549b0886ddd48b58dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", ":eva:ListaExamenes.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "    Examenes Creados";
    }

    // line 6
    public function block_titulo($context, array $blocks = array())
    {
        // line 7
        echo "    Examenes Curso:
    ";
    }

    // line 11
    public function block_btn1href($context, array $blocks = array())
    {
        // line 12
        echo "    /docente
";
    }

    // line 14
    public function block_btn1($context, array $blocks = array())
    {
        // line 15
        echo "    Salir
";
    }

    // line 17
    public function block_btn2href($context, array $blocks = array())
    {
    }

    // line 18
    public function block_btn2($context, array $blocks = array())
    {
    }

    // line 20
    public function block_LeftColumn($context, array $blocks = array())
    {
        // line 21
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;\t\">
            Previamente Creados</h5>
        <p>
            Lista de Examenes
        </p>
        <div class=\"button-group\">
            <a class=\"secondary button\">Ver</a>
            <a class=\"success button\">Habilitar</a>
            <a class=\"warning button\">Editar</a>
            <a class=\"alert button\">Eliminar</a>
        </div>
    </div>
";
    }

    // line 36
    public function block_field($context, array $blocks = array())
    {
        // line 37
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;\t\">
            Por Calificar</h5>
        <p>
            Examenes Por Calificar, añadir Tabla:
        </p>
        <div class=\"button-group\">
            Presentado por : NombreEstudiante. |
            <button class=\"hollow button\" href=\"#\">
                NombreExamen</button>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return ":eva:ListaExamenes.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 37,  96 => 36,  79 => 21,  76 => 20,  71 => 18,  66 => 17,  61 => 15,  58 => 14,  53 => 12,  50 => 11,  45 => 7,  42 => 6,  38 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* */
/* {% block title %}*/
/*     Examenes Creados{% endblock %}*/
/* */
/* {% block titulo %}*/
/*     Examenes Curso:*/
/*     {#Añadir Nombre Curso#}*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /docente*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir*/
/* {% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}{% endblock %}*/
/* */
/* {% block LeftColumn %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;	">*/
/*             Previamente Creados</h5>*/
/*         <p>*/
/*             Lista de Examenes*/
/*         </p>*/
/*         <div class="button-group">*/
/*             <a class="secondary button">Ver</a>*/
/*             <a class="success button">Habilitar</a>*/
/*             <a class="warning button">Editar</a>*/
/*             <a class="alert button">Eliminar</a>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block field %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;	">*/
/*             Por Calificar</h5>*/
/*         <p>*/
/*             Examenes Por Calificar, añadir Tabla:*/
/*         </p>*/
/*         <div class="button-group">*/
/*             Presentado por : NombreEstudiante. |*/
/*             <button class="hollow button" href="#">*/
/*                 NombreExamen</button>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
