<?php

/* :eva:presentarExam.html.twig */
class __TwigTemplate_8c0082ff7aa8d50520e8566a2c0a3537fd678b1a45511ee9de09bac218c75aee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", ":eva:presentarExam.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btnAdicional' => array($this, 'block_btnAdicional'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
    }

    // line 5
    public function block_titulo($context, array $blocks = array())
    {
        echo "Examen: ";
        echo " Curso: ";
    }

    // line 8
    public function block_btn1href($context, array $blocks = array())
    {
        // line 9
        echo "    /student
";
    }

    // line 11
    public function block_btn1($context, array $blocks = array())
    {
        // line 12
        echo "    Salir Sin Guardar";
    }

    // line 13
    public function block_btn2href($context, array $blocks = array())
    {
    }

    // line 14
    public function block_btn2($context, array $blocks = array())
    {
        echo "Guardar y Enviar Examen";
    }

    // line 16
    public function block_btnAdicional($context, array $blocks = array())
    {
    }

    // line 17
    public function block_LeftColumn($context, array $blocks = array())
    {
    }

    // line 19
    public function block_field($context, array $blocks = array())
    {
        // line 20
        echo "<div class=\"radar_post\"><div class=\"radar_content\"><div class=\"photo_post\"><div style=\"font-family: 'Calligraffitti', cursive; font-size:20px; background:#2FCAC2 \" class=\"thumbnail_anchor\">Tiempo total:  <hr> Tiempo Restante: <br> Cantidad de Preguntas: <br> Teimpo promedio para cada pregunta:  <a class=\"radar_superglass\" href=\"\"></a> </div></div></div>
";
    }

    public function getTemplateName()
    {
        return ":eva:presentarExam.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 20,  84 => 19,  79 => 17,  74 => 16,  68 => 14,  63 => 13,  59 => 12,  56 => 11,  51 => 9,  48 => 8,  41 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* */
/* {% block title %}{% endblock %}*/
/* */
/* {% block titulo %}Examen: {# nombreExamen #} Curso: {# nombreCurso #}*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /student*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir Sin Guardar{% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}Guardar y Enviar Examen{% endblock %}*/
/* */
/* {% block btnAdicional %}{% endblock %}*/
/* {% block LeftColumn %}{% endblock %}*/
/* */
/* {% block field %}*/
/* <div class="radar_post"><div class="radar_content"><div class="photo_post"><div style="font-family: 'Calligraffitti', cursive; font-size:20px; background:#2FCAC2 " class="thumbnail_anchor">Tiempo total:  <hr> Tiempo Restante: <br> Cantidad de Preguntas: <br> Teimpo promedio para cada pregunta:  <a class="radar_superglass" href=""></a> </div></div></div>*/
/* {% endblock %}*/
/* */
