<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_7195895680644f4b8b8f77758c6f6b0c183ff424e2e209458641659cb3eaacd3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
