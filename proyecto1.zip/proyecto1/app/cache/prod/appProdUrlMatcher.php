<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // homepage2
        if ($pathinfo === '/uno') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::unoAction',  '_route' => 'homepage2',);
        }

        // homepage3
        if ($pathinfo === '/dos') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::dosAction',  '_route' => 'homepage3',);
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::indexAction',  '_route' => 'homepage',);
        }

        // PáginaPrincipal
        if ($pathinfo === '/main') {
            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::mainAction',  '_route' => 'PáginaPrincipal',);
        }

        // createExam
        if ($pathinfo === '/createExam') {
            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::createExamAction',  '_route' => 'createExam',);
        }

        // docente
        if ($pathinfo === '/docente') {
            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::docenteAction',  '_route' => 'docente',);
        }

        // invitado
        if ($pathinfo === '/invitado') {
            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::invitadoAction',  '_route' => 'invitado',);
        }

        // listaExmanes
        if ($pathinfo === '/ListaExamenes') {
            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::ListaExamenesAction',  '_route' => 'listaExmanes',);
        }

        // plantilla
        if ($pathinfo === '/plantilla') {
            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::plantillaAction',  '_route' => 'plantilla',);
        }

        // estudiante
        if ($pathinfo === '/student') {
            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::studentAction',  '_route' => 'estudiante',);
        }

        // presentarExam
        if ($pathinfo === '/presentarExam') {
            return array (  '_controller' => 'AppBundle\\Controller\\EvaController::presentarExamAction',  '_route' => 'presentarExam',);
        }

        // app_lucky_number
        if ($pathinfo === '/lucky/number') {
            return array (  '_controller' => 'AppBundle\\Controller\\LuckyController::numberAction',  '_route' => 'app_lucky_number',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
