<?php

/* eva/createExam.html.twig */
class __TwigTemplate_3b81cb854927c4897559b98a5bb22b82cadd128a80404e3805c7ba9bc8b6016b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/createExam.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btnAdicional' => array($this, 'block_btnAdicional'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_971215a42f674b8b1b8e63a7b8a0acaf07a9d0a301b8c4d8780434c50bd15e05 = $this->env->getExtension("native_profiler");
        $__internal_971215a42f674b8b1b8e63a7b8a0acaf07a9d0a301b8c4d8780434c50bd15e05->enter($__internal_971215a42f674b8b1b8e63a7b8a0acaf07a9d0a301b8c4d8780434c50bd15e05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/createExam.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_971215a42f674b8b1b8e63a7b8a0acaf07a9d0a301b8c4d8780434c50bd15e05->leave($__internal_971215a42f674b8b1b8e63a7b8a0acaf07a9d0a301b8c4d8780434c50bd15e05_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_427c5b6cb6d4a69447a1c4f3bde3751348a9dbe3ff94494430d5eccb53ce19c0 = $this->env->getExtension("native_profiler");
        $__internal_427c5b6cb6d4a69447a1c4f3bde3751348a9dbe3ff94494430d5eccb53ce19c0->enter($__internal_427c5b6cb6d4a69447a1c4f3bde3751348a9dbe3ff94494430d5eccb53ce19c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    createExam!";
        
        $__internal_427c5b6cb6d4a69447a1c4f3bde3751348a9dbe3ff94494430d5eccb53ce19c0->leave($__internal_427c5b6cb6d4a69447a1c4f3bde3751348a9dbe3ff94494430d5eccb53ce19c0_prof);

    }

    // line 6
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_c851dda5c1c2914190bbcb4e3a1c7faac1572e91e973020e05d2a3d8fff96acc = $this->env->getExtension("native_profiler");
        $__internal_c851dda5c1c2914190bbcb4e3a1c7faac1572e91e973020e05d2a3d8fff96acc->enter($__internal_c851dda5c1c2914190bbcb4e3a1c7faac1572e91e973020e05d2a3d8fff96acc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        $this->displayParentBlock("titulo", $context, $blocks);
        
        $__internal_c851dda5c1c2914190bbcb4e3a1c7faac1572e91e973020e05d2a3d8fff96acc->leave($__internal_c851dda5c1c2914190bbcb4e3a1c7faac1572e91e973020e05d2a3d8fff96acc_prof);

    }

    // line 8
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_29609d52ef3982811688022b2dc81dad1a03d8fc541f0cf67a672bd794909f91 = $this->env->getExtension("native_profiler");
        $__internal_29609d52ef3982811688022b2dc81dad1a03d8fc541f0cf67a672bd794909f91->enter($__internal_29609d52ef3982811688022b2dc81dad1a03d8fc541f0cf67a672bd794909f91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        // line 9
        echo "    /docente
";
        
        $__internal_29609d52ef3982811688022b2dc81dad1a03d8fc541f0cf67a672bd794909f91->leave($__internal_29609d52ef3982811688022b2dc81dad1a03d8fc541f0cf67a672bd794909f91_prof);

    }

    // line 11
    public function block_btn1($context, array $blocks = array())
    {
        $__internal_39be26b6065e308618c8463080779d8cc4886335cd99e487bad4ae7fc2844048 = $this->env->getExtension("native_profiler");
        $__internal_39be26b6065e308618c8463080779d8cc4886335cd99e487bad4ae7fc2844048->enter($__internal_39be26b6065e308618c8463080779d8cc4886335cd99e487bad4ae7fc2844048_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        // line 12
        echo "    Salir Sin Guardar";
        
        $__internal_39be26b6065e308618c8463080779d8cc4886335cd99e487bad4ae7fc2844048->leave($__internal_39be26b6065e308618c8463080779d8cc4886335cd99e487bad4ae7fc2844048_prof);

    }

    // line 13
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_7de7e19078bc450d2de318e35a90ff4d78b9de3e9a058700427d7083e0b12cf1 = $this->env->getExtension("native_profiler");
        $__internal_7de7e19078bc450d2de318e35a90ff4d78b9de3e9a058700427d7083e0b12cf1->enter($__internal_7de7e19078bc450d2de318e35a90ff4d78b9de3e9a058700427d7083e0b12cf1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        
        $__internal_7de7e19078bc450d2de318e35a90ff4d78b9de3e9a058700427d7083e0b12cf1->leave($__internal_7de7e19078bc450d2de318e35a90ff4d78b9de3e9a058700427d7083e0b12cf1_prof);

    }

    // line 14
    public function block_btn2($context, array $blocks = array())
    {
        $__internal_2c06917eab9c20459abfbaa5d489586c19e4290775ab5f21858269d58736c718 = $this->env->getExtension("native_profiler");
        $__internal_2c06917eab9c20459abfbaa5d489586c19e4290775ab5f21858269d58736c718->enter($__internal_2c06917eab9c20459abfbaa5d489586c19e4290775ab5f21858269d58736c718_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        echo "Guardar Examen";
        
        $__internal_2c06917eab9c20459abfbaa5d489586c19e4290775ab5f21858269d58736c718->leave($__internal_2c06917eab9c20459abfbaa5d489586c19e4290775ab5f21858269d58736c718_prof);

    }

    // line 16
    public function block_btnAdicional($context, array $blocks = array())
    {
        $__internal_4d7e0c152fd577c1a326edeb654620ab0779795459d8ef6b859d923dc1e4e56e = $this->env->getExtension("native_profiler");
        $__internal_4d7e0c152fd577c1a326edeb654620ab0779795459d8ef6b859d923dc1e4e56e->enter($__internal_4d7e0c152fd577c1a326edeb654620ab0779795459d8ef6b859d923dc1e4e56e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btnAdicional"));

        // line 17
        echo "    <li class=\"has-submenu\">
        <a href=\"#\">
            Añadir Pregunta
        </a>
        <ul class=\"submenu menu vertical\" data-submenu>
        <li>
            <a href=\"#\">Pregunta para Adjuntar Archivo</a>
        </li>
        <li>
            <a href=\"#\">Pregunta Abierta</a>
        </li>
        <li>
            <a href=\"#\">Pregunta de Selección múltiple con múltiple Respuesta</a>
        </li>
        <li>
            <a href=\"#\">Pregunta de Falso o Verdadero</a>
        </li>
        <li>
            <a href=\"#\">Pregunta para Unir</a>
        </li>
        <li>
            <a href=\"#\"></a>
        </li>
    </ul>
</li>
";
        
        $__internal_4d7e0c152fd577c1a326edeb654620ab0779795459d8ef6b859d923dc1e4e56e->leave($__internal_4d7e0c152fd577c1a326edeb654620ab0779795459d8ef6b859d923dc1e4e56e_prof);

    }

    // line 43
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_df9ef9f4fcc87f9766bd2ac4a19a90fdaf6c217dbb42392d110d9b432c48e8bb = $this->env->getExtension("native_profiler");
        $__internal_df9ef9f4fcc87f9766bd2ac4a19a90fdaf6c217dbb42392d110d9b432c48e8bb->enter($__internal_df9ef9f4fcc87f9766bd2ac4a19a90fdaf6c217dbb42392d110d9b432c48e8bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        // line 44
        echo "
<div class=\"callout\">
    <h5>
        (1).<textarea
            title=\"Porfavor, Ingrese la pregunta en este espacio\"
            class=\"uiTextareaAutogrow _3en1\"
            name=\"xhpc_message\"
            placeholder=\"Porfavor, Ingrese la pregunta en este espacio\"
            onkeydown=\"run_with(this, [&quot;legacy:control-textarea&quot;], function() &#123;TextAreaControl.getInstance(this)&#125;);\"></textarea>
    </h5>
    <ul class=\"button-group round even-8\">
        <li>
            <a href=\"#\" class=\"button\">Añadir Opción</a>
        </li>
        <form method=\"get\" action=\"http://aprenderaprogramar.com/action.php\">
       <br />
       <br />
       <input name=\"intereses\" type=\"radio\" value=\"rbiinternet\" checked=\"checked\" />OpciónUno

       </form>

_________________________________________________________________________________________----
        <li>
            <a href=\"#\" class=\"button\">Seleccionar Respuesta</a>
        </li>
        <li>
            <a href=\"#\" class=\"button\">Guardar</a>
        </li>
        <li>
            <a href=\"#\" class=\"button\">Eliminar</a>
        </li>
    </ul>
</div>

";
        
        $__internal_df9ef9f4fcc87f9766bd2ac4a19a90fdaf6c217dbb42392d110d9b432c48e8bb->leave($__internal_df9ef9f4fcc87f9766bd2ac4a19a90fdaf6c217dbb42392d110d9b432c48e8bb_prof);

    }

    // line 80
    public function block_field($context, array $blocks = array())
    {
        $__internal_71b21ff8de3779dd0950632bd7b72ba9adf353bbfaab7078b269bf6591c01287 = $this->env->getExtension("native_profiler");
        $__internal_71b21ff8de3779dd0950632bd7b72ba9adf353bbfaab7078b269bf6591c01287->enter($__internal_71b21ff8de3779dd0950632bd7b72ba9adf353bbfaab7078b269bf6591c01287_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 81
        echo "Porfavor, adicione una pregunta.
<div class=\"large-4 columns\">
    <h4>-</h4>
    <a href=\"#\" data-reveal-id=\"firstModal\" class=\"radius button\">Question…</a>

    <div style=\"display: none;\"></div>

    <div style=\"display: none; opacity: 1; visibility: hidden; top: 842px;\" id=\"secondModal\" class=\"reveal-modal\" data-reveal=\"\" aria-labelledby=\"secondModalTitle\" aria-hidden=\"true\" role=\"dialog\">
        <h2 id=\"secondModalTitle\">This is a second modal.</h2>
        <p>See? It just slides into place after the other first modal. Very handy when you need subsequent dialogs, or when a modal option impacts or requires another decision.</p>
        <a class=\"close-reveal-modal\" aria-label=\"Close\">×</a>
    </div>

</div>
";
        
        $__internal_71b21ff8de3779dd0950632bd7b72ba9adf353bbfaab7078b269bf6591c01287->leave($__internal_71b21ff8de3779dd0950632bd7b72ba9adf353bbfaab7078b269bf6591c01287_prof);

    }

    public function getTemplateName()
    {
        return "eva/createExam.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  208 => 81,  202 => 80,  161 => 44,  155 => 43,  123 => 17,  117 => 16,  105 => 14,  94 => 13,  87 => 12,  81 => 11,  73 => 9,  67 => 8,  55 => 6,  48 => 4,  42 => 3,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* */
/* {% block title %}*/
/*     createExam!{% endblock %}*/
/* */
/* {% block titulo %}{{parent()}}{% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /docente*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir Sin Guardar{% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}Guardar Examen{% endblock %}*/
/* */
/* {% block btnAdicional %}*/
/*     <li class="has-submenu">*/
/*         <a href="#">*/
/*             Añadir Pregunta*/
/*         </a>*/
/*         <ul class="submenu menu vertical" data-submenu>*/
/*         <li>*/
/*             <a href="#">Pregunta para Adjuntar Archivo</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#">Pregunta Abierta</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#">Pregunta de Selección múltiple con múltiple Respuesta</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#">Pregunta de Falso o Verdadero</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#">Pregunta para Unir</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#"></a>*/
/*         </li>*/
/*     </ul>*/
/* </li>*/
/* {% endblock %}*/
/* {% block LeftColumn %}*/
/* */
/* <div class="callout">*/
/*     <h5>*/
/*         (1).<textarea*/
/*             title="Porfavor, Ingrese la pregunta en este espacio"*/
/*             class="uiTextareaAutogrow _3en1"*/
/*             name="xhpc_message"*/
/*             placeholder="Porfavor, Ingrese la pregunta en este espacio"*/
/*             onkeydown="run_with(this, [&quot;legacy:control-textarea&quot;], function() &#123;TextAreaControl.getInstance(this)&#125;);"></textarea>*/
/*     </h5>*/
/*     <ul class="button-group round even-8">*/
/*         <li>*/
/*             <a href="#" class="button">Añadir Opción</a>*/
/*         </li>*/
/*         <form method="get" action="http://aprenderaprogramar.com/action.php">*/
/*        <br />*/
/*        <br />*/
/*        <input name="intereses" type="radio" value="rbiinternet" checked="checked" />OpciónUno*/
/* */
/*        </form>*/
/* */
/* _________________________________________________________________________________________----*/
/*         <li>*/
/*             <a href="#" class="button">Seleccionar Respuesta</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#" class="button">Guardar</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="#" class="button">Eliminar</a>*/
/*         </li>*/
/*     </ul>*/
/* </div>*/
/* */
/* {% endblock %}*/
/* */
/* {% block field %}*/
/* Porfavor, adicione una pregunta.*/
/* <div class="large-4 columns">*/
/*     <h4>-</h4>*/
/*     <a href="#" data-reveal-id="firstModal" class="radius button">Question…</a>*/
/* */
/*     <div style="display: none;"></div>*/
/* */
/*     <div style="display: none; opacity: 1; visibility: hidden; top: 842px;" id="secondModal" class="reveal-modal" data-reveal="" aria-labelledby="secondModalTitle" aria-hidden="true" role="dialog">*/
/*         <h2 id="secondModalTitle">This is a second modal.</h2>*/
/*         <p>See? It just slides into place after the other first modal. Very handy when you need subsequent dialogs, or when a modal option impacts or requires another decision.</p>*/
/*         <a class="close-reveal-modal" aria-label="Close">×</a>*/
/*     </div>*/
/* */
/* </div>*/
/* {% endblock %}*/
/* */
