<?php

/* eva/presentarExam.html.twig */
class __TwigTemplate_3023b4fca2408926d5b73ce94742df0a762c894354d26e189a1ccd9db094c7e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/presentarExam.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btnAdicional' => array($this, 'block_btnAdicional'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f10ab44e4f4955327f7bcb5c1b9c1f9bbca0b213d7f04d794051bcfa0213c022 = $this->env->getExtension("native_profiler");
        $__internal_f10ab44e4f4955327f7bcb5c1b9c1f9bbca0b213d7f04d794051bcfa0213c022->enter($__internal_f10ab44e4f4955327f7bcb5c1b9c1f9bbca0b213d7f04d794051bcfa0213c022_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/presentarExam.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f10ab44e4f4955327f7bcb5c1b9c1f9bbca0b213d7f04d794051bcfa0213c022->leave($__internal_f10ab44e4f4955327f7bcb5c1b9c1f9bbca0b213d7f04d794051bcfa0213c022_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_444ee33b0b77059df7ce4011b593164b3c37707c3c1d5f1d288e8d0ed5e37a8e = $this->env->getExtension("native_profiler");
        $__internal_444ee33b0b77059df7ce4011b593164b3c37707c3c1d5f1d288e8d0ed5e37a8e->enter($__internal_444ee33b0b77059df7ce4011b593164b3c37707c3c1d5f1d288e8d0ed5e37a8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_444ee33b0b77059df7ce4011b593164b3c37707c3c1d5f1d288e8d0ed5e37a8e->leave($__internal_444ee33b0b77059df7ce4011b593164b3c37707c3c1d5f1d288e8d0ed5e37a8e_prof);

    }

    // line 5
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_d17c74d688bea6ceef714ad2ede7eac5cafddf3621c79f47d1575d704ee15105 = $this->env->getExtension("native_profiler");
        $__internal_d17c74d688bea6ceef714ad2ede7eac5cafddf3621c79f47d1575d704ee15105->enter($__internal_d17c74d688bea6ceef714ad2ede7eac5cafddf3621c79f47d1575d704ee15105_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        echo "Examen: ";
        echo " Curso: ";
        
        $__internal_d17c74d688bea6ceef714ad2ede7eac5cafddf3621c79f47d1575d704ee15105->leave($__internal_d17c74d688bea6ceef714ad2ede7eac5cafddf3621c79f47d1575d704ee15105_prof);

    }

    // line 8
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_7ee7f1d52ccb6cac7590d1361e8ff2843284ed3f4edc065b7920cee945f9e255 = $this->env->getExtension("native_profiler");
        $__internal_7ee7f1d52ccb6cac7590d1361e8ff2843284ed3f4edc065b7920cee945f9e255->enter($__internal_7ee7f1d52ccb6cac7590d1361e8ff2843284ed3f4edc065b7920cee945f9e255_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        // line 9
        echo "    /student
";
        
        $__internal_7ee7f1d52ccb6cac7590d1361e8ff2843284ed3f4edc065b7920cee945f9e255->leave($__internal_7ee7f1d52ccb6cac7590d1361e8ff2843284ed3f4edc065b7920cee945f9e255_prof);

    }

    // line 11
    public function block_btn1($context, array $blocks = array())
    {
        $__internal_7858a934ff9294899de463b925c72779ebe1f648ae0eec927c6492dfea6bcbd0 = $this->env->getExtension("native_profiler");
        $__internal_7858a934ff9294899de463b925c72779ebe1f648ae0eec927c6492dfea6bcbd0->enter($__internal_7858a934ff9294899de463b925c72779ebe1f648ae0eec927c6492dfea6bcbd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        // line 12
        echo "    Salir Sin Guardar";
        
        $__internal_7858a934ff9294899de463b925c72779ebe1f648ae0eec927c6492dfea6bcbd0->leave($__internal_7858a934ff9294899de463b925c72779ebe1f648ae0eec927c6492dfea6bcbd0_prof);

    }

    // line 13
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_b61136ba1bffac7eb12eadf4f0bd2a2d13974284658be12f30d84fe213f2beba = $this->env->getExtension("native_profiler");
        $__internal_b61136ba1bffac7eb12eadf4f0bd2a2d13974284658be12f30d84fe213f2beba->enter($__internal_b61136ba1bffac7eb12eadf4f0bd2a2d13974284658be12f30d84fe213f2beba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        
        $__internal_b61136ba1bffac7eb12eadf4f0bd2a2d13974284658be12f30d84fe213f2beba->leave($__internal_b61136ba1bffac7eb12eadf4f0bd2a2d13974284658be12f30d84fe213f2beba_prof);

    }

    // line 14
    public function block_btn2($context, array $blocks = array())
    {
        $__internal_14a1d06a996edaf678afb839ca5015ed24940151e6a98ca8bd147ee5c005f5b3 = $this->env->getExtension("native_profiler");
        $__internal_14a1d06a996edaf678afb839ca5015ed24940151e6a98ca8bd147ee5c005f5b3->enter($__internal_14a1d06a996edaf678afb839ca5015ed24940151e6a98ca8bd147ee5c005f5b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        echo "Guardar y Enviar Examen";
        
        $__internal_14a1d06a996edaf678afb839ca5015ed24940151e6a98ca8bd147ee5c005f5b3->leave($__internal_14a1d06a996edaf678afb839ca5015ed24940151e6a98ca8bd147ee5c005f5b3_prof);

    }

    // line 16
    public function block_btnAdicional($context, array $blocks = array())
    {
        $__internal_bd111d35a6eb07ebfc801a42fa2a456f52d03181c9df7d42e69615f07e0288ea = $this->env->getExtension("native_profiler");
        $__internal_bd111d35a6eb07ebfc801a42fa2a456f52d03181c9df7d42e69615f07e0288ea->enter($__internal_bd111d35a6eb07ebfc801a42fa2a456f52d03181c9df7d42e69615f07e0288ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btnAdicional"));

        
        $__internal_bd111d35a6eb07ebfc801a42fa2a456f52d03181c9df7d42e69615f07e0288ea->leave($__internal_bd111d35a6eb07ebfc801a42fa2a456f52d03181c9df7d42e69615f07e0288ea_prof);

    }

    // line 17
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_acc00daa219ae0c88b7cc3d6f59855df5aa35500f1e35c676f839c7731505b9c = $this->env->getExtension("native_profiler");
        $__internal_acc00daa219ae0c88b7cc3d6f59855df5aa35500f1e35c676f839c7731505b9c->enter($__internal_acc00daa219ae0c88b7cc3d6f59855df5aa35500f1e35c676f839c7731505b9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        
        $__internal_acc00daa219ae0c88b7cc3d6f59855df5aa35500f1e35c676f839c7731505b9c->leave($__internal_acc00daa219ae0c88b7cc3d6f59855df5aa35500f1e35c676f839c7731505b9c_prof);

    }

    // line 19
    public function block_field($context, array $blocks = array())
    {
        $__internal_12e0f6da792f0a4998bb187ab055ebd6d6bed4774ec54c0dd5be5ab83a7fb3fa = $this->env->getExtension("native_profiler");
        $__internal_12e0f6da792f0a4998bb187ab055ebd6d6bed4774ec54c0dd5be5ab83a7fb3fa->enter($__internal_12e0f6da792f0a4998bb187ab055ebd6d6bed4774ec54c0dd5be5ab83a7fb3fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 20
        echo "<div class=\"radar_post\"><div class=\"radar_content\"><div class=\"photo_post\"><div style=\"font-family: 'Calligraffitti', cursive; font-size:20px; background:#2FCAC2 \" class=\"thumbnail_anchor\">Tiempo total:  <hr> Tiempo Restante: <br> Cantidad de Preguntas: <br> Teimpo promedio para cada pregunta:  <a class=\"radar_superglass\" href=\"\"></a> </div></div></div>
";
        
        $__internal_12e0f6da792f0a4998bb187ab055ebd6d6bed4774ec54c0dd5be5ab83a7fb3fa->leave($__internal_12e0f6da792f0a4998bb187ab055ebd6d6bed4774ec54c0dd5be5ab83a7fb3fa_prof);

    }

    public function getTemplateName()
    {
        return "eva/presentarExam.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 20,  138 => 19,  127 => 17,  116 => 16,  104 => 14,  93 => 13,  86 => 12,  80 => 11,  72 => 9,  66 => 8,  53 => 5,  42 => 3,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* */
/* {% block title %}{% endblock %}*/
/* */
/* {% block titulo %}Examen: {# nombreExamen #} Curso: {# nombreCurso #}*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /student*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir Sin Guardar{% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}Guardar y Enviar Examen{% endblock %}*/
/* */
/* {% block btnAdicional %}{% endblock %}*/
/* {% block LeftColumn %}{% endblock %}*/
/* */
/* {% block field %}*/
/* <div class="radar_post"><div class="radar_content"><div class="photo_post"><div style="font-family: 'Calligraffitti', cursive; font-size:20px; background:#2FCAC2 " class="thumbnail_anchor">Tiempo total:  <hr> Tiempo Restante: <br> Cantidad de Preguntas: <br> Teimpo promedio para cada pregunta:  <a class="radar_superglass" href=""></a> </div></div></div>*/
/* {% endblock %}*/
/* */
