<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_711629b3ebee3d91764ed0a9c8818bf75817f209e5dfe547ab8d91775668a13e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4cb9378ef3f67d079001b57f3f4e45892da150ec3e3ab535bb7c03c50d9e91a1 = $this->env->getExtension("native_profiler");
        $__internal_4cb9378ef3f67d079001b57f3f4e45892da150ec3e3ab535bb7c03c50d9e91a1->enter($__internal_4cb9378ef3f67d079001b57f3f4e45892da150ec3e3ab535bb7c03c50d9e91a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4cb9378ef3f67d079001b57f3f4e45892da150ec3e3ab535bb7c03c50d9e91a1->leave($__internal_4cb9378ef3f67d079001b57f3f4e45892da150ec3e3ab535bb7c03c50d9e91a1_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_85dec9b942cc3e965b50052b6c9ecf51e54f442b52f8208a642d1fb8e2048fbe = $this->env->getExtension("native_profiler");
        $__internal_85dec9b942cc3e965b50052b6c9ecf51e54f442b52f8208a642d1fb8e2048fbe->enter($__internal_85dec9b942cc3e965b50052b6c9ecf51e54f442b52f8208a642d1fb8e2048fbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_85dec9b942cc3e965b50052b6c9ecf51e54f442b52f8208a642d1fb8e2048fbe->leave($__internal_85dec9b942cc3e965b50052b6c9ecf51e54f442b52f8208a642d1fb8e2048fbe_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_0bc532aaa3a4b424133dded4ae8ab15cd64f20823c4daa4f4e0111847db63c8b = $this->env->getExtension("native_profiler");
        $__internal_0bc532aaa3a4b424133dded4ae8ab15cd64f20823c4daa4f4e0111847db63c8b->enter($__internal_0bc532aaa3a4b424133dded4ae8ab15cd64f20823c4daa4f4e0111847db63c8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0bc532aaa3a4b424133dded4ae8ab15cd64f20823c4daa4f4e0111847db63c8b->leave($__internal_0bc532aaa3a4b424133dded4ae8ab15cd64f20823c4daa4f4e0111847db63c8b_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_621be8e05a7e551cd63e4e4b83645b95091dd3045e4b80a2617d2a66d38adac0 = $this->env->getExtension("native_profiler");
        $__internal_621be8e05a7e551cd63e4e4b83645b95091dd3045e4b80a2617d2a66d38adac0->enter($__internal_621be8e05a7e551cd63e4e4b83645b95091dd3045e4b80a2617d2a66d38adac0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_621be8e05a7e551cd63e4e4b83645b95091dd3045e4b80a2617d2a66d38adac0->leave($__internal_621be8e05a7e551cd63e4e4b83645b95091dd3045e4b80a2617d2a66d38adac0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
