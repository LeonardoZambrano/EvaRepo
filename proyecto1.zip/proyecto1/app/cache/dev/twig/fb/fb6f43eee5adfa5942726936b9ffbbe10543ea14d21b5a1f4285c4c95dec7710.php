<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_8bbd357cc87ce53b4cc2bc86a13b461b33ff94f927f7b7684c6a0af06d52840d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5d53f41215c71958ec634568f454ab3d303202ff9a1067029537f2c7edbd115f = $this->env->getExtension("native_profiler");
        $__internal_5d53f41215c71958ec634568f454ab3d303202ff9a1067029537f2c7edbd115f->enter($__internal_5d53f41215c71958ec634568f454ab3d303202ff9a1067029537f2c7edbd115f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5d53f41215c71958ec634568f454ab3d303202ff9a1067029537f2c7edbd115f->leave($__internal_5d53f41215c71958ec634568f454ab3d303202ff9a1067029537f2c7edbd115f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_03b3fb3155d812b18f801da59b3e532a60e275599551d745c6eec8b977495487 = $this->env->getExtension("native_profiler");
        $__internal_03b3fb3155d812b18f801da59b3e532a60e275599551d745c6eec8b977495487->enter($__internal_03b3fb3155d812b18f801da59b3e532a60e275599551d745c6eec8b977495487_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_03b3fb3155d812b18f801da59b3e532a60e275599551d745c6eec8b977495487->leave($__internal_03b3fb3155d812b18f801da59b3e532a60e275599551d745c6eec8b977495487_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_82491d331c4274b654351aaee5726ff00a847b537ebc08bfe433cd676cd271e0 = $this->env->getExtension("native_profiler");
        $__internal_82491d331c4274b654351aaee5726ff00a847b537ebc08bfe433cd676cd271e0->enter($__internal_82491d331c4274b654351aaee5726ff00a847b537ebc08bfe433cd676cd271e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_82491d331c4274b654351aaee5726ff00a847b537ebc08bfe433cd676cd271e0->leave($__internal_82491d331c4274b654351aaee5726ff00a847b537ebc08bfe433cd676cd271e0_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_adb96abcfb098f52ad3018d714aee435d77a23dd3269b310521bb8726db37de2 = $this->env->getExtension("native_profiler");
        $__internal_adb96abcfb098f52ad3018d714aee435d77a23dd3269b310521bb8726db37de2->enter($__internal_adb96abcfb098f52ad3018d714aee435d77a23dd3269b310521bb8726db37de2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_adb96abcfb098f52ad3018d714aee435d77a23dd3269b310521bb8726db37de2->leave($__internal_adb96abcfb098f52ad3018d714aee435d77a23dd3269b310521bb8726db37de2_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
