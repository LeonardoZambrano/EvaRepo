<?php

/* eva/estudiante.html.twig */
class __TwigTemplate_4117599d6bd2ba9903c7f3168091b732508181cda88776bc8aaf4dff79ef14cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/estudiante.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_896a3dc8c3653b37a1080389f500d91051a546d55be11bd9d18862a6e1b897f5 = $this->env->getExtension("native_profiler");
        $__internal_896a3dc8c3653b37a1080389f500d91051a546d55be11bd9d18862a6e1b897f5->enter($__internal_896a3dc8c3653b37a1080389f500d91051a546d55be11bd9d18862a6e1b897f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/estudiante.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_896a3dc8c3653b37a1080389f500d91051a546d55be11bd9d18862a6e1b897f5->leave($__internal_896a3dc8c3653b37a1080389f500d91051a546d55be11bd9d18862a6e1b897f5_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_ab185453c444354621d84a673e2c95ab79e0766ab8940a5aebcafbb8a39b5ef6 = $this->env->getExtension("native_profiler");
        $__internal_ab185453c444354621d84a673e2c95ab79e0766ab8940a5aebcafbb8a39b5ef6->enter($__internal_ab185453c444354621d84a673e2c95ab79e0766ab8940a5aebcafbb8a39b5ef6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 3
        echo "    Examenes Creados";
        
        $__internal_ab185453c444354621d84a673e2c95ab79e0766ab8940a5aebcafbb8a39b5ef6->leave($__internal_ab185453c444354621d84a673e2c95ab79e0766ab8940a5aebcafbb8a39b5ef6_prof);

    }

    // line 5
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_5fef9dc2217fe24a977bbb022ef64391cc65db1a190559e42b21d055c40218de = $this->env->getExtension("native_profiler");
        $__internal_5fef9dc2217fe24a977bbb022ef64391cc65db1a190559e42b21d055c40218de->enter($__internal_5fef9dc2217fe24a977bbb022ef64391cc65db1a190559e42b21d055c40218de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        // line 6
        echo "    Cursos...
    ";
        
        $__internal_5fef9dc2217fe24a977bbb022ef64391cc65db1a190559e42b21d055c40218de->leave($__internal_5fef9dc2217fe24a977bbb022ef64391cc65db1a190559e42b21d055c40218de_prof);

    }

    // line 10
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_efdffbc61490b5866a00212b3267c86347d5b21cab3b8608d21e95e7b79278c9 = $this->env->getExtension("native_profiler");
        $__internal_efdffbc61490b5866a00212b3267c86347d5b21cab3b8608d21e95e7b79278c9->enter($__internal_efdffbc61490b5866a00212b3267c86347d5b21cab3b8608d21e95e7b79278c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        // line 11
        echo "    /main
";
        
        $__internal_efdffbc61490b5866a00212b3267c86347d5b21cab3b8608d21e95e7b79278c9->leave($__internal_efdffbc61490b5866a00212b3267c86347d5b21cab3b8608d21e95e7b79278c9_prof);

    }

    // line 13
    public function block_btn1($context, array $blocks = array())
    {
        $__internal_1aefdec8d9d15da7b6ef0eaa680ebd5ca9c877516ffb65201e61b8ff1b18d083 = $this->env->getExtension("native_profiler");
        $__internal_1aefdec8d9d15da7b6ef0eaa680ebd5ca9c877516ffb65201e61b8ff1b18d083->enter($__internal_1aefdec8d9d15da7b6ef0eaa680ebd5ca9c877516ffb65201e61b8ff1b18d083_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        // line 14
        echo "    Salir
";
        
        $__internal_1aefdec8d9d15da7b6ef0eaa680ebd5ca9c877516ffb65201e61b8ff1b18d083->leave($__internal_1aefdec8d9d15da7b6ef0eaa680ebd5ca9c877516ffb65201e61b8ff1b18d083_prof);

    }

    // line 16
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_6fb222951accf41a4fa54c68d22c3a0bd19f00da661097d558bc14ae8a9d4b6b = $this->env->getExtension("native_profiler");
        $__internal_6fb222951accf41a4fa54c68d22c3a0bd19f00da661097d558bc14ae8a9d4b6b->enter($__internal_6fb222951accf41a4fa54c68d22c3a0bd19f00da661097d558bc14ae8a9d4b6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        
        $__internal_6fb222951accf41a4fa54c68d22c3a0bd19f00da661097d558bc14ae8a9d4b6b->leave($__internal_6fb222951accf41a4fa54c68d22c3a0bd19f00da661097d558bc14ae8a9d4b6b_prof);

    }

    // line 17
    public function block_btn2($context, array $blocks = array())
    {
        $__internal_30efbcb173e7c2b2c231dd68182511b8e79d9062656e082243796452e2e0c814 = $this->env->getExtension("native_profiler");
        $__internal_30efbcb173e7c2b2c231dd68182511b8e79d9062656e082243796452e2e0c814->enter($__internal_30efbcb173e7c2b2c231dd68182511b8e79d9062656e082243796452e2e0c814_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        
        $__internal_30efbcb173e7c2b2c231dd68182511b8e79d9062656e082243796452e2e0c814->leave($__internal_30efbcb173e7c2b2c231dd68182511b8e79d9062656e082243796452e2e0c814_prof);

    }

    // line 19
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_9d31a78aa594b0a4577411c1c313ceeeb501a55c0216961a2680786fa63b31f9 = $this->env->getExtension("native_profiler");
        $__internal_9d31a78aa594b0a4577411c1c313ceeeb501a55c0216961a2680786fa63b31f9->enter($__internal_9d31a78aa594b0a4577411c1c313ceeeb501a55c0216961a2680786fa63b31f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        // line 20
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;\t\">
            Primer Curso Inscrito</h5>
        <p>
            Docente: _______<br>
            Email: ____________

        </p>
        <div class=\"button-group\">
          ";
        // line 30
        echo "          <a href=\"/presentarExam\" type=\"submit\" class=\"success button\"> Presentar Examen </a>

            <a class=\"warning button\">Editar</a>
            <a class=\"alert button\">Abandonar Curso</a>
        </div>
    </div>
";
        
        $__internal_9d31a78aa594b0a4577411c1c313ceeeb501a55c0216961a2680786fa63b31f9->leave($__internal_9d31a78aa594b0a4577411c1c313ceeeb501a55c0216961a2680786fa63b31f9_prof);

    }

    // line 38
    public function block_field($context, array $blocks = array())
    {
        $__internal_b52f0d6caaf0529031941a760f6ef9f54aa4de4278af6413367646fdd771086f = $this->env->getExtension("native_profiler");
        $__internal_b52f0d6caaf0529031941a760f6ef9f54aa4de4278af6413367646fdd771086f->enter($__internal_b52f0d6caaf0529031941a760f6ef9f54aa4de4278af6413367646fdd771086f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 39
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;\t\">
            Cursos Disponibles</h5>
        <p>
            Añadir Tabla:
        </p>
        <div class=\"cursoUno\">

        <button class=\"hollow button\" href=\"#\">
            Inscribir</button>
            Docente: _____  Información acerca del curso
        </div>
    </div>
";
        
        $__internal_b52f0d6caaf0529031941a760f6ef9f54aa4de4278af6413367646fdd771086f->leave($__internal_b52f0d6caaf0529031941a760f6ef9f54aa4de4278af6413367646fdd771086f_prof);

    }

    public function getTemplateName()
    {
        return "eva/estudiante.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 39,  148 => 38,  135 => 30,  124 => 20,  118 => 19,  107 => 17,  96 => 16,  88 => 14,  82 => 13,  74 => 11,  68 => 10,  60 => 6,  54 => 5,  47 => 3,  41 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}*/
/*     Examenes Creados{% endblock %}*/
/* */
/* {% block titulo %}*/
/*     Cursos...*/
/*     {#Añadir Nombre Curso#}*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /main*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir*/
/* {% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}{% endblock %}*/
/* */
/* {% block LeftColumn %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;	">*/
/*             Primer Curso Inscrito</h5>*/
/*         <p>*/
/*             Docente: _______<br>*/
/*             Email: ____________*/
/* */
/*         </p>*/
/*         <div class="button-group">*/
/*           {# <a class="secondary button">Asignar Hora Examen</a>#}*/
/*           <a href="/presentarExam" type="submit" class="success button"> Presentar Examen </a>*/
/* */
/*             <a class="warning button">Editar</a>*/
/*             <a class="alert button">Abandonar Curso</a>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block field %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;	">*/
/*             Cursos Disponibles</h5>*/
/*         <p>*/
/*             Añadir Tabla:*/
/*         </p>*/
/*         <div class="cursoUno">*/
/* */
/*         <button class="hollow button" href="#">*/
/*             Inscribir</button>*/
/*             Docente: _____  Información acerca del curso*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
