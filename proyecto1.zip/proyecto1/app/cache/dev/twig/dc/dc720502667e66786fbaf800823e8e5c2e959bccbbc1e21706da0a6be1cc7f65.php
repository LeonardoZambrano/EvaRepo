<?php

/* base.html.twig */
class __TwigTemplate_ef640e53014425f01a26c68b1388e0ec67c62529705945946596c0bef2961153 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1dfc7dc2b82df51c8bbdba3e1debea4b2bac5e7a9b96f61341b2c6726ee213ea = $this->env->getExtension("native_profiler");
        $__internal_1dfc7dc2b82df51c8bbdba3e1debea4b2bac5e7a9b96f61341b2c6726ee213ea->enter($__internal_1dfc7dc2b82df51c8bbdba3e1debea4b2bac5e7a9b96f61341b2c6726ee213ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_1dfc7dc2b82df51c8bbdba3e1debea4b2bac5e7a9b96f61341b2c6726ee213ea->leave($__internal_1dfc7dc2b82df51c8bbdba3e1debea4b2bac5e7a9b96f61341b2c6726ee213ea_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_26e0422396fb19261cd41439de242c40f934a44054a8a587d76b9ca355fdf83d = $this->env->getExtension("native_profiler");
        $__internal_26e0422396fb19261cd41439de242c40f934a44054a8a587d76b9ca355fdf83d->enter($__internal_26e0422396fb19261cd41439de242c40f934a44054a8a587d76b9ca355fdf83d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_26e0422396fb19261cd41439de242c40f934a44054a8a587d76b9ca355fdf83d->leave($__internal_26e0422396fb19261cd41439de242c40f934a44054a8a587d76b9ca355fdf83d_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e6e7e59d7cac31e65184c3656d0067e0f0709b8253d5765776b2e021db0c42a7 = $this->env->getExtension("native_profiler");
        $__internal_e6e7e59d7cac31e65184c3656d0067e0f0709b8253d5765776b2e021db0c42a7->enter($__internal_e6e7e59d7cac31e65184c3656d0067e0f0709b8253d5765776b2e021db0c42a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_e6e7e59d7cac31e65184c3656d0067e0f0709b8253d5765776b2e021db0c42a7->leave($__internal_e6e7e59d7cac31e65184c3656d0067e0f0709b8253d5765776b2e021db0c42a7_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_b3e37de24bdcffef969ca4287482746580db7a6f48cd2ed143b60065b557fdff = $this->env->getExtension("native_profiler");
        $__internal_b3e37de24bdcffef969ca4287482746580db7a6f48cd2ed143b60065b557fdff->enter($__internal_b3e37de24bdcffef969ca4287482746580db7a6f48cd2ed143b60065b557fdff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_b3e37de24bdcffef969ca4287482746580db7a6f48cd2ed143b60065b557fdff->leave($__internal_b3e37de24bdcffef969ca4287482746580db7a6f48cd2ed143b60065b557fdff_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e461279fec0de971b6d22405274eae5375a14e7fbf8719cd2fd7d4464875a7b3 = $this->env->getExtension("native_profiler");
        $__internal_e461279fec0de971b6d22405274eae5375a14e7fbf8719cd2fd7d4464875a7b3->enter($__internal_e461279fec0de971b6d22405274eae5375a14e7fbf8719cd2fd7d4464875a7b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_e461279fec0de971b6d22405274eae5375a14e7fbf8719cd2fd7d4464875a7b3->leave($__internal_e461279fec0de971b6d22405274eae5375a14e7fbf8719cd2fd7d4464875a7b3_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
