<?php

/* eva/presentarExam.html.twig */
class __TwigTemplate_9ab4f60c14c5f98da7ed4219779b4a4e8d2c6e1ad82a4147a6928715e8361bd8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/presentarExam.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btnAdicional' => array($this, 'block_btnAdicional'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4f99aaf2698b0993b96a18daf9303a2bdf0c64326fc4c84ab2a6175803968033 = $this->env->getExtension("native_profiler");
        $__internal_4f99aaf2698b0993b96a18daf9303a2bdf0c64326fc4c84ab2a6175803968033->enter($__internal_4f99aaf2698b0993b96a18daf9303a2bdf0c64326fc4c84ab2a6175803968033_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/presentarExam.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4f99aaf2698b0993b96a18daf9303a2bdf0c64326fc4c84ab2a6175803968033->leave($__internal_4f99aaf2698b0993b96a18daf9303a2bdf0c64326fc4c84ab2a6175803968033_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a867a3cd3671f97238ab1000bce551e32f673e6df30d23797dc94c95435f4b52 = $this->env->getExtension("native_profiler");
        $__internal_a867a3cd3671f97238ab1000bce551e32f673e6df30d23797dc94c95435f4b52->enter($__internal_a867a3cd3671f97238ab1000bce551e32f673e6df30d23797dc94c95435f4b52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_a867a3cd3671f97238ab1000bce551e32f673e6df30d23797dc94c95435f4b52->leave($__internal_a867a3cd3671f97238ab1000bce551e32f673e6df30d23797dc94c95435f4b52_prof);

    }

    // line 5
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_89f6ea6317d731a5b53785db7c1c2b6fdb78fa25c6b4dc40b7e2a102c4e112be = $this->env->getExtension("native_profiler");
        $__internal_89f6ea6317d731a5b53785db7c1c2b6fdb78fa25c6b4dc40b7e2a102c4e112be->enter($__internal_89f6ea6317d731a5b53785db7c1c2b6fdb78fa25c6b4dc40b7e2a102c4e112be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        echo "Examen: ";
        echo " Curso: ";
        
        $__internal_89f6ea6317d731a5b53785db7c1c2b6fdb78fa25c6b4dc40b7e2a102c4e112be->leave($__internal_89f6ea6317d731a5b53785db7c1c2b6fdb78fa25c6b4dc40b7e2a102c4e112be_prof);

    }

    // line 8
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_1412676832eb270ebcf32f3ad95aeb2d55e723dd4767ab367aa0dbee19d40196 = $this->env->getExtension("native_profiler");
        $__internal_1412676832eb270ebcf32f3ad95aeb2d55e723dd4767ab367aa0dbee19d40196->enter($__internal_1412676832eb270ebcf32f3ad95aeb2d55e723dd4767ab367aa0dbee19d40196_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        // line 9
        echo "    /student
";
        
        $__internal_1412676832eb270ebcf32f3ad95aeb2d55e723dd4767ab367aa0dbee19d40196->leave($__internal_1412676832eb270ebcf32f3ad95aeb2d55e723dd4767ab367aa0dbee19d40196_prof);

    }

    // line 11
    public function block_btn1($context, array $blocks = array())
    {
        $__internal_7d49a79816476dbbbf299be89408908268651acfa0762a0355809523dc528782 = $this->env->getExtension("native_profiler");
        $__internal_7d49a79816476dbbbf299be89408908268651acfa0762a0355809523dc528782->enter($__internal_7d49a79816476dbbbf299be89408908268651acfa0762a0355809523dc528782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        // line 12
        echo "    Salir Sin Guardar";
        
        $__internal_7d49a79816476dbbbf299be89408908268651acfa0762a0355809523dc528782->leave($__internal_7d49a79816476dbbbf299be89408908268651acfa0762a0355809523dc528782_prof);

    }

    // line 13
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_cb785b9973977b3dcd90fe0cd7e23714c1e27c5f942a632a2522f500bc86befa = $this->env->getExtension("native_profiler");
        $__internal_cb785b9973977b3dcd90fe0cd7e23714c1e27c5f942a632a2522f500bc86befa->enter($__internal_cb785b9973977b3dcd90fe0cd7e23714c1e27c5f942a632a2522f500bc86befa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        
        $__internal_cb785b9973977b3dcd90fe0cd7e23714c1e27c5f942a632a2522f500bc86befa->leave($__internal_cb785b9973977b3dcd90fe0cd7e23714c1e27c5f942a632a2522f500bc86befa_prof);

    }

    // line 14
    public function block_btn2($context, array $blocks = array())
    {
        $__internal_858bc2651a60857d6de8b0b64ec1e0ba00390f7b39a792fdb679d2a9dff41da3 = $this->env->getExtension("native_profiler");
        $__internal_858bc2651a60857d6de8b0b64ec1e0ba00390f7b39a792fdb679d2a9dff41da3->enter($__internal_858bc2651a60857d6de8b0b64ec1e0ba00390f7b39a792fdb679d2a9dff41da3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        echo "Guardar y Enviar Examen";
        
        $__internal_858bc2651a60857d6de8b0b64ec1e0ba00390f7b39a792fdb679d2a9dff41da3->leave($__internal_858bc2651a60857d6de8b0b64ec1e0ba00390f7b39a792fdb679d2a9dff41da3_prof);

    }

    // line 16
    public function block_btnAdicional($context, array $blocks = array())
    {
        $__internal_61cf0c2fe4238d1e7c8a68812ff0d5b1607625c8678739d8338455d7ea0b2a32 = $this->env->getExtension("native_profiler");
        $__internal_61cf0c2fe4238d1e7c8a68812ff0d5b1607625c8678739d8338455d7ea0b2a32->enter($__internal_61cf0c2fe4238d1e7c8a68812ff0d5b1607625c8678739d8338455d7ea0b2a32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btnAdicional"));

        
        $__internal_61cf0c2fe4238d1e7c8a68812ff0d5b1607625c8678739d8338455d7ea0b2a32->leave($__internal_61cf0c2fe4238d1e7c8a68812ff0d5b1607625c8678739d8338455d7ea0b2a32_prof);

    }

    // line 17
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_435586d3273388bc7fe2b65acb3cc3bf6389f6b1c26c8976ac17b916bb6f3a60 = $this->env->getExtension("native_profiler");
        $__internal_435586d3273388bc7fe2b65acb3cc3bf6389f6b1c26c8976ac17b916bb6f3a60->enter($__internal_435586d3273388bc7fe2b65acb3cc3bf6389f6b1c26c8976ac17b916bb6f3a60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        
        $__internal_435586d3273388bc7fe2b65acb3cc3bf6389f6b1c26c8976ac17b916bb6f3a60->leave($__internal_435586d3273388bc7fe2b65acb3cc3bf6389f6b1c26c8976ac17b916bb6f3a60_prof);

    }

    // line 19
    public function block_field($context, array $blocks = array())
    {
        $__internal_ea994c5a5523ba7595a34dd990e197ffb5b48d0f63a33fd0b5d0223c73976239 = $this->env->getExtension("native_profiler");
        $__internal_ea994c5a5523ba7595a34dd990e197ffb5b48d0f63a33fd0b5d0223c73976239->enter($__internal_ea994c5a5523ba7595a34dd990e197ffb5b48d0f63a33fd0b5d0223c73976239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 20
        echo "<div class=\"radar_post\"><div class=\"radar_content\"><div class=\"photo_post\"><div style=\"font-family: 'Calligraffitti', cursive; font-size:20px; background:#2FCAC2 \" class=\"thumbnail_anchor\">Tiempo total:  <hr> Tiempo Restante: <br> Cantidad de Preguntas: <br> Teimpo promedio para cada pregunta:  <a class=\"radar_superglass\" href=\"\"></a> </div></div></div>
";
        
        $__internal_ea994c5a5523ba7595a34dd990e197ffb5b48d0f63a33fd0b5d0223c73976239->leave($__internal_ea994c5a5523ba7595a34dd990e197ffb5b48d0f63a33fd0b5d0223c73976239_prof);

    }

    public function getTemplateName()
    {
        return "eva/presentarExam.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 20,  138 => 19,  127 => 17,  116 => 16,  104 => 14,  93 => 13,  86 => 12,  80 => 11,  72 => 9,  66 => 8,  53 => 5,  42 => 3,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* */
/* {% block title %}{% endblock %}*/
/* */
/* {% block titulo %}Examen: {# nombreExamen #} Curso: {# nombreCurso #}*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /student*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir Sin Guardar{% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}Guardar y Enviar Examen{% endblock %}*/
/* */
/* {% block btnAdicional %}{% endblock %}*/
/* {% block LeftColumn %}{% endblock %}*/
/* */
/* {% block field %}*/
/* <div class="radar_post"><div class="radar_content"><div class="photo_post"><div style="font-family: 'Calligraffitti', cursive; font-size:20px; background:#2FCAC2 " class="thumbnail_anchor">Tiempo total:  <hr> Tiempo Restante: <br> Cantidad de Preguntas: <br> Teimpo promedio para cada pregunta:  <a class="radar_superglass" href=""></a> </div></div></div>*/
/* {% endblock %}*/
/* */
