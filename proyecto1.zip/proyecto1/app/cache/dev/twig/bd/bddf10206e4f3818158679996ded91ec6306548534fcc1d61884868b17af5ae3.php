<?php

/* eva/estudiante.html.twig */
class __TwigTemplate_a97fa401fc94af5a231aca0dc6237f8b3bf260d9bd63d9d728625d9ea340d797 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/estudiante.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f0b0633e1fd4edf5465e83c82a18212d3b9e4f5a7e56593a951ceb7240046824 = $this->env->getExtension("native_profiler");
        $__internal_f0b0633e1fd4edf5465e83c82a18212d3b9e4f5a7e56593a951ceb7240046824->enter($__internal_f0b0633e1fd4edf5465e83c82a18212d3b9e4f5a7e56593a951ceb7240046824_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/estudiante.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f0b0633e1fd4edf5465e83c82a18212d3b9e4f5a7e56593a951ceb7240046824->leave($__internal_f0b0633e1fd4edf5465e83c82a18212d3b9e4f5a7e56593a951ceb7240046824_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_5849d81027420773e08b53293c1697a1d2f5b3e2e5586d7189b47a7b18940871 = $this->env->getExtension("native_profiler");
        $__internal_5849d81027420773e08b53293c1697a1d2f5b3e2e5586d7189b47a7b18940871->enter($__internal_5849d81027420773e08b53293c1697a1d2f5b3e2e5586d7189b47a7b18940871_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 3
        echo "    Examenes Creados";
        
        $__internal_5849d81027420773e08b53293c1697a1d2f5b3e2e5586d7189b47a7b18940871->leave($__internal_5849d81027420773e08b53293c1697a1d2f5b3e2e5586d7189b47a7b18940871_prof);

    }

    // line 5
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_58d567078db524547cce59886c11beef156ebf0c92a51ea02ded1d1e41902d6f = $this->env->getExtension("native_profiler");
        $__internal_58d567078db524547cce59886c11beef156ebf0c92a51ea02ded1d1e41902d6f->enter($__internal_58d567078db524547cce59886c11beef156ebf0c92a51ea02ded1d1e41902d6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        // line 6
        echo "    Cursos...
    ";
        
        $__internal_58d567078db524547cce59886c11beef156ebf0c92a51ea02ded1d1e41902d6f->leave($__internal_58d567078db524547cce59886c11beef156ebf0c92a51ea02ded1d1e41902d6f_prof);

    }

    // line 10
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_5a3a94beb554088054474de8dcb544ce3536853507f2c862c5b3b532b31feba0 = $this->env->getExtension("native_profiler");
        $__internal_5a3a94beb554088054474de8dcb544ce3536853507f2c862c5b3b532b31feba0->enter($__internal_5a3a94beb554088054474de8dcb544ce3536853507f2c862c5b3b532b31feba0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        // line 11
        echo "    /main
";
        
        $__internal_5a3a94beb554088054474de8dcb544ce3536853507f2c862c5b3b532b31feba0->leave($__internal_5a3a94beb554088054474de8dcb544ce3536853507f2c862c5b3b532b31feba0_prof);

    }

    // line 13
    public function block_btn1($context, array $blocks = array())
    {
        $__internal_9843d503a2e199bfafa5007b20daa665faf8e742ff58fc3d7ed17f02257d5d07 = $this->env->getExtension("native_profiler");
        $__internal_9843d503a2e199bfafa5007b20daa665faf8e742ff58fc3d7ed17f02257d5d07->enter($__internal_9843d503a2e199bfafa5007b20daa665faf8e742ff58fc3d7ed17f02257d5d07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        // line 14
        echo "    Salir
";
        
        $__internal_9843d503a2e199bfafa5007b20daa665faf8e742ff58fc3d7ed17f02257d5d07->leave($__internal_9843d503a2e199bfafa5007b20daa665faf8e742ff58fc3d7ed17f02257d5d07_prof);

    }

    // line 16
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_ad354cd932595260ffa24f39652c64305ae52ab3106f0d156a0db1296f4c23dd = $this->env->getExtension("native_profiler");
        $__internal_ad354cd932595260ffa24f39652c64305ae52ab3106f0d156a0db1296f4c23dd->enter($__internal_ad354cd932595260ffa24f39652c64305ae52ab3106f0d156a0db1296f4c23dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        
        $__internal_ad354cd932595260ffa24f39652c64305ae52ab3106f0d156a0db1296f4c23dd->leave($__internal_ad354cd932595260ffa24f39652c64305ae52ab3106f0d156a0db1296f4c23dd_prof);

    }

    // line 17
    public function block_btn2($context, array $blocks = array())
    {
        $__internal_21ea42bc8b9c1236485b3da884d37542e7fc7b80a0e9e78758daf5f96fe540dd = $this->env->getExtension("native_profiler");
        $__internal_21ea42bc8b9c1236485b3da884d37542e7fc7b80a0e9e78758daf5f96fe540dd->enter($__internal_21ea42bc8b9c1236485b3da884d37542e7fc7b80a0e9e78758daf5f96fe540dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        
        $__internal_21ea42bc8b9c1236485b3da884d37542e7fc7b80a0e9e78758daf5f96fe540dd->leave($__internal_21ea42bc8b9c1236485b3da884d37542e7fc7b80a0e9e78758daf5f96fe540dd_prof);

    }

    // line 19
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_bf2eed4e77fc739401efcef324139a91f46bc993e0f867abff7c0ac3f13ad1f5 = $this->env->getExtension("native_profiler");
        $__internal_bf2eed4e77fc739401efcef324139a91f46bc993e0f867abff7c0ac3f13ad1f5->enter($__internal_bf2eed4e77fc739401efcef324139a91f46bc993e0f867abff7c0ac3f13ad1f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        // line 20
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;\t\">
            Primer Curso Inscrito</h5>
        <p>
            Docente: _______<br>
            Email: ____________

        </p>
        <div class=\"button-group\">
          ";
        // line 30
        echo "          <a href=\"/presentarExam\" type=\"submit\" class=\"success button\"> Presentar Examen </a>

            <a class=\"warning button\">Editar</a>
            <a class=\"alert button\">Abandonar Curso</a>
        </div>
    </div>
";
        
        $__internal_bf2eed4e77fc739401efcef324139a91f46bc993e0f867abff7c0ac3f13ad1f5->leave($__internal_bf2eed4e77fc739401efcef324139a91f46bc993e0f867abff7c0ac3f13ad1f5_prof);

    }

    // line 38
    public function block_field($context, array $blocks = array())
    {
        $__internal_8706f4f9b9da95431267dde5ba19282919a023c0325f9d2922d4961bd16b368d = $this->env->getExtension("native_profiler");
        $__internal_8706f4f9b9da95431267dde5ba19282919a023c0325f9d2922d4961bd16b368d->enter($__internal_8706f4f9b9da95431267dde5ba19282919a023c0325f9d2922d4961bd16b368d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 39
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;\t\">
            Cursos Disponibles</h5>
        <p>
            Añadir Tabla:
        </p>
        <div class=\"cursoUno\">

        <button class=\"hollow button\" href=\"#\">
            Inscribir</button>
            Docente: _____  Información acerca del curso
        </div>
    </div>
";
        
        $__internal_8706f4f9b9da95431267dde5ba19282919a023c0325f9d2922d4961bd16b368d->leave($__internal_8706f4f9b9da95431267dde5ba19282919a023c0325f9d2922d4961bd16b368d_prof);

    }

    public function getTemplateName()
    {
        return "eva/estudiante.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 39,  148 => 38,  135 => 30,  124 => 20,  118 => 19,  107 => 17,  96 => 16,  88 => 14,  82 => 13,  74 => 11,  68 => 10,  60 => 6,  54 => 5,  47 => 3,  41 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}*/
/*     Examenes Creados{% endblock %}*/
/* */
/* {% block titulo %}*/
/*     Cursos...*/
/*     {#Añadir Nombre Curso#}*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /main*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir*/
/* {% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}{% endblock %}*/
/* */
/* {% block LeftColumn %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;	">*/
/*             Primer Curso Inscrito</h5>*/
/*         <p>*/
/*             Docente: _______<br>*/
/*             Email: ____________*/
/* */
/*         </p>*/
/*         <div class="button-group">*/
/*           {# <a class="secondary button">Asignar Hora Examen</a>#}*/
/*           <a href="/presentarExam" type="submit" class="success button"> Presentar Examen </a>*/
/* */
/*             <a class="warning button">Editar</a>*/
/*             <a class="alert button">Abandonar Curso</a>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block field %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;	">*/
/*             Cursos Disponibles</h5>*/
/*         <p>*/
/*             Añadir Tabla:*/
/*         </p>*/
/*         <div class="cursoUno">*/
/* */
/*         <button class="hollow button" href="#">*/
/*             Inscribir</button>*/
/*             Docente: _____  Información acerca del curso*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
