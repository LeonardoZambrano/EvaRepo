<?php

/* eva/invitado.html.twig */
class __TwigTemplate_a2b855d96991b0beb857257a0c53e48056f153cd196d6aca0400085b5b7a846c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/invitado.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14a03ff8a0dd835ee74c488ac400c45a5c18be261cbadd9d2e4b832bdbae9085 = $this->env->getExtension("native_profiler");
        $__internal_14a03ff8a0dd835ee74c488ac400c45a5c18be261cbadd9d2e4b832bdbae9085->enter($__internal_14a03ff8a0dd835ee74c488ac400c45a5c18be261cbadd9d2e4b832bdbae9085_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/invitado.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_14a03ff8a0dd835ee74c488ac400c45a5c18be261cbadd9d2e4b832bdbae9085->leave($__internal_14a03ff8a0dd835ee74c488ac400c45a5c18be261cbadd9d2e4b832bdbae9085_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_c9fd82722699503be0803112c35a2268c166f036113192dc8a8130da4a4705d3 = $this->env->getExtension("native_profiler");
        $__internal_c9fd82722699503be0803112c35a2268c166f036113192dc8a8130da4a4705d3->enter($__internal_c9fd82722699503be0803112c35a2268c166f036113192dc8a8130da4a4705d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Cursos ";
        
        $__internal_c9fd82722699503be0803112c35a2268c166f036113192dc8a8130da4a4705d3->leave($__internal_c9fd82722699503be0803112c35a2268c166f036113192dc8a8130da4a4705d3_prof);

    }

    // line 3
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_cf371401407a8840a906bb1a4ca5bfd989d58156b45426ec124bf13e24a8a754 = $this->env->getExtension("native_profiler");
        $__internal_cf371401407a8840a906bb1a4ca5bfd989d58156b45426ec124bf13e24a8a754->enter($__internal_cf371401407a8840a906bb1a4ca5bfd989d58156b45426ec124bf13e24a8a754_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        // line 4
        echo "
";
        
        $__internal_cf371401407a8840a906bb1a4ca5bfd989d58156b45426ec124bf13e24a8a754->leave($__internal_cf371401407a8840a906bb1a4ca5bfd989d58156b45426ec124bf13e24a8a754_prof);

    }

    public function getTemplateName()
    {
        return "eva/invitado.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 4,  47 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}Cursos {% endblock %}*/
/* {% block LeftColumn %}*/
/* */
/* {% endblock %}*/
/* */
