<?php

/* eva/ListaExamenes.html.twig */
class __TwigTemplate_02229ae9d3e714bf6376b9b4eeacaa4bb1129d81a0fbbb1c402a1397d929ba2e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/ListaExamenes.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1f5d3f0dd84e19d17ef24ed241aa91fa96e1186febd66a444e5bff6ea555eada = $this->env->getExtension("native_profiler");
        $__internal_1f5d3f0dd84e19d17ef24ed241aa91fa96e1186febd66a444e5bff6ea555eada->enter($__internal_1f5d3f0dd84e19d17ef24ed241aa91fa96e1186febd66a444e5bff6ea555eada_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/ListaExamenes.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1f5d3f0dd84e19d17ef24ed241aa91fa96e1186febd66a444e5bff6ea555eada->leave($__internal_1f5d3f0dd84e19d17ef24ed241aa91fa96e1186febd66a444e5bff6ea555eada_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_02777718c7bcec8f73eb0e68cec5d3b14c080c9d2872a1241e09a12356987523 = $this->env->getExtension("native_profiler");
        $__internal_02777718c7bcec8f73eb0e68cec5d3b14c080c9d2872a1241e09a12356987523->enter($__internal_02777718c7bcec8f73eb0e68cec5d3b14c080c9d2872a1241e09a12356987523_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Examenes Creados";
        
        $__internal_02777718c7bcec8f73eb0e68cec5d3b14c080c9d2872a1241e09a12356987523->leave($__internal_02777718c7bcec8f73eb0e68cec5d3b14c080c9d2872a1241e09a12356987523_prof);

    }

    // line 6
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_1ebe6cddfffa5549dfe23f7302aad41d261a6372441770c9074dcc6462ebea3e = $this->env->getExtension("native_profiler");
        $__internal_1ebe6cddfffa5549dfe23f7302aad41d261a6372441770c9074dcc6462ebea3e->enter($__internal_1ebe6cddfffa5549dfe23f7302aad41d261a6372441770c9074dcc6462ebea3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        // line 7
        echo "    Examenes Curso:
    ";
        
        $__internal_1ebe6cddfffa5549dfe23f7302aad41d261a6372441770c9074dcc6462ebea3e->leave($__internal_1ebe6cddfffa5549dfe23f7302aad41d261a6372441770c9074dcc6462ebea3e_prof);

    }

    // line 11
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_57f9ece3030bd9471729eaf16235d557e30d0fde33e7808398164b07e659e28f = $this->env->getExtension("native_profiler");
        $__internal_57f9ece3030bd9471729eaf16235d557e30d0fde33e7808398164b07e659e28f->enter($__internal_57f9ece3030bd9471729eaf16235d557e30d0fde33e7808398164b07e659e28f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        // line 12
        echo "    /docente
";
        
        $__internal_57f9ece3030bd9471729eaf16235d557e30d0fde33e7808398164b07e659e28f->leave($__internal_57f9ece3030bd9471729eaf16235d557e30d0fde33e7808398164b07e659e28f_prof);

    }

    // line 14
    public function block_btn1($context, array $blocks = array())
    {
        $__internal_42f2afcc3874b1505504a6f9782ce17fa0f3e2c1d19fb260efcdfdc4baad92ef = $this->env->getExtension("native_profiler");
        $__internal_42f2afcc3874b1505504a6f9782ce17fa0f3e2c1d19fb260efcdfdc4baad92ef->enter($__internal_42f2afcc3874b1505504a6f9782ce17fa0f3e2c1d19fb260efcdfdc4baad92ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        // line 15
        echo "    Salir
";
        
        $__internal_42f2afcc3874b1505504a6f9782ce17fa0f3e2c1d19fb260efcdfdc4baad92ef->leave($__internal_42f2afcc3874b1505504a6f9782ce17fa0f3e2c1d19fb260efcdfdc4baad92ef_prof);

    }

    // line 17
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_a54d07010dfe96394c26552ee0d2de833927b25a2875872f20939e92fafb87a6 = $this->env->getExtension("native_profiler");
        $__internal_a54d07010dfe96394c26552ee0d2de833927b25a2875872f20939e92fafb87a6->enter($__internal_a54d07010dfe96394c26552ee0d2de833927b25a2875872f20939e92fafb87a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        
        $__internal_a54d07010dfe96394c26552ee0d2de833927b25a2875872f20939e92fafb87a6->leave($__internal_a54d07010dfe96394c26552ee0d2de833927b25a2875872f20939e92fafb87a6_prof);

    }

    // line 18
    public function block_btn2($context, array $blocks = array())
    {
        $__internal_7174a513f4fe69179883848ec976bd988dc51420494a295b6d54dcd032a6443a = $this->env->getExtension("native_profiler");
        $__internal_7174a513f4fe69179883848ec976bd988dc51420494a295b6d54dcd032a6443a->enter($__internal_7174a513f4fe69179883848ec976bd988dc51420494a295b6d54dcd032a6443a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        
        $__internal_7174a513f4fe69179883848ec976bd988dc51420494a295b6d54dcd032a6443a->leave($__internal_7174a513f4fe69179883848ec976bd988dc51420494a295b6d54dcd032a6443a_prof);

    }

    // line 20
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_18c5e391b2e16d34aaad73e0842859fbcbbfe63253866fcf296c1439f92fdaf3 = $this->env->getExtension("native_profiler");
        $__internal_18c5e391b2e16d34aaad73e0842859fbcbbfe63253866fcf296c1439f92fdaf3->enter($__internal_18c5e391b2e16d34aaad73e0842859fbcbbfe63253866fcf296c1439f92fdaf3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        // line 21
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;\t\">
            Previamente Creados</h5>
        <p>
            Lista de Examenes
        </p>
        <div class=\"button-group\">
            <a class=\"secondary button\">Ver</a>
            <a class=\"success button\">Habilitar</a>
            <a class=\"warning button\">Editar</a>
            <a class=\"alert button\">Eliminar</a>
        </div>
    </div>
";
        
        $__internal_18c5e391b2e16d34aaad73e0842859fbcbbfe63253866fcf296c1439f92fdaf3->leave($__internal_18c5e391b2e16d34aaad73e0842859fbcbbfe63253866fcf296c1439f92fdaf3_prof);

    }

    // line 36
    public function block_field($context, array $blocks = array())
    {
        $__internal_e073e3688807df799998cb93650cdc4d186e6bddbd5e2baf92f57cfdd59c76d8 = $this->env->getExtension("native_profiler");
        $__internal_e073e3688807df799998cb93650cdc4d186e6bddbd5e2baf92f57cfdd59c76d8->enter($__internal_e073e3688807df799998cb93650cdc4d186e6bddbd5e2baf92f57cfdd59c76d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 37
        echo "    <div class=\"callout large\">
        <h5 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;\t\">
            Por Calificar</h5>
        <p>
            Examenes Por Calificar, añadir Tabla:
        </p>
        <div class=\"button-group\">
            Presentado por : NombreEstudiante. |
            <button class=\"hollow button\" href=\"#\">
                NombreExamen</button>
        </div>
    </div>
";
        
        $__internal_e073e3688807df799998cb93650cdc4d186e6bddbd5e2baf92f57cfdd59c76d8->leave($__internal_e073e3688807df799998cb93650cdc4d186e6bddbd5e2baf92f57cfdd59c76d8_prof);

    }

    public function getTemplateName()
    {
        return "eva/ListaExamenes.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  150 => 37,  144 => 36,  124 => 21,  118 => 20,  107 => 18,  96 => 17,  88 => 15,  82 => 14,  74 => 12,  68 => 11,  60 => 7,  54 => 6,  47 => 4,  41 => 3,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* */
/* {% block title %}*/
/*     Examenes Creados{% endblock %}*/
/* */
/* {% block titulo %}*/
/*     Examenes Curso:*/
/*     {#Añadir Nombre Curso#}*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /docente*/
/* {% endblock %}*/
/* {% block btn1 %}*/
/*     Salir*/
/* {% endblock %}*/
/* {% block btn2href %}{% endblock %}*/
/* {% block btn2 %}{% endblock %}*/
/* */
/* {% block LeftColumn %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:56px;	">*/
/*             Previamente Creados</h5>*/
/*         <p>*/
/*             Lista de Examenes*/
/*         </p>*/
/*         <div class="button-group">*/
/*             <a class="secondary button">Ver</a>*/
/*             <a class="success button">Habilitar</a>*/
/*             <a class="warning button">Editar</a>*/
/*             <a class="alert button">Eliminar</a>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block field %}*/
/*     <div class="callout large">*/
/*         <h5 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'Tangerine', cursive; font-size:50px;	">*/
/*             Por Calificar</h5>*/
/*         <p>*/
/*             Examenes Por Calificar, añadir Tabla:*/
/*         </p>*/
/*         <div class="button-group">*/
/*             Presentado por : NombreEstudiante. |*/
/*             <button class="hollow button" href="#">*/
/*                 NombreExamen</button>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
