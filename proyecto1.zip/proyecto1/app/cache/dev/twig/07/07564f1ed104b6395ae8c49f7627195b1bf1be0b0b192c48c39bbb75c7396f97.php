<?php

/* evabase.html.twig */
class __TwigTemplate_662abc0093da1dbffe3d8d6f7f6a05881e6ae03d961285ce8c3a4ea85c074b6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btn3href' => array($this, 'block_btn3href'),
            'btn3' => array($this, 'block_btn3'),
            'btnAdicional' => array($this, 'block_btnAdicional'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'field' => array($this, 'block_field'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97bbe62f4bab5a991ce01552014d6a644635f19a006485e6c6f2e2434392bdbb = $this->env->getExtension("native_profiler");
        $__internal_97bbe62f4bab5a991ce01552014d6a644635f19a006485e6c6f2e2434392bdbb->enter($__internal_97bbe62f4bab5a991ce01552014d6a644635f19a006485e6c6f2e2434392bdbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "evabase.html.twig"));

        // line 1
        echo "<!doctype html>
<html class=\"no-js\" lang=\"en\">

<head>
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title> ~ Eva |";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <!--Inclusi�n de Fuentes, tomadas de:https://www.google.com/fonts/-->
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Calligraffitti' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=sans-serif' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>

    <link rel=\"stylesheet\" href=\"http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css\">
    <link href='http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css' rel='stylesheet' type='text/css'> ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>

<body>
    <style>
        .eva {
            -webkit-box-sizing: content-box;
            -moz-box-sizing: content-box;
            box-sizing: content-box;
            border: none;
            font: normal 130px/1 \"cookie\", 'Norican', sans-serif;
            color: rgba(0, 0, 0, 1);
            -o-text-overflow: ellipsis;
            text-overflow: ellipsis;
            background: rgb(255, 255, 255);
            text-shadow: 4px 4px 6px rgba(0, 155, 255, 0.8);
            -webkit-transform: rotateX(-32.65859432245692deg) rotateY(5.156620156177409deg);
            transform: rotateX(-32.65859432245692deg) rotateY(5.156620156177409deg);
        }



        .fi-social-facebook {
            color: dodgerblue;
            font-size: 2rem;
        }

        .fi-social-youtube {
            color: red;
            font-size: 2rem;
        }

        .fi-social-twitter {
            color: skyblue;
            font-size: 2rem;
        }

        body {
            margin-top: 2rem;
        }

        .title-bar {
            background: #333;
            padding: 0.9rem;
        }

        .top-bar {
            background: #333;
        }

        .top-bar ul {
            background: #333;
        }

        .top-bar ul li {
            background: #333;
        }

        .top-bar ul li a {
            color: #fff;
        }

        .menu-text {
            color: #fff;
        }

        @media only screen and (max-width: 40em) {
            .menu-text {
                display: none !important;
            }
        }

        @media only screen and (min-width: 40em) {
            .top-bar .menu:last-child {
                border-left: 1px solid #4e4e4e;
            }
            .top-bar .menu:first-child {
                border-left: none;
            }
            .top-bar .menu li:not(:last-child) {
                border-right: 1px solid #4e4e4e;
            }
        }

        .dropdown.menu .submenu {
            border: none;
        }

        .dropdown.menu .is-dropdown-submenu-parent.is-right-arrow > a::after {
            border-color: #fff transparent transparent;
        }

        .is-drilldown-submenu-parent > a::after {
            border-color: transparent transparent transparent #fff;
        }

        .js-drilldown-back::before {
            border-color: transparent #fff transparent transparent;
        }
    </style>
    <header>
        ";
        // line 122
        echo "        <div class=\"row\">
            <div class=\"medium columns expanded text-center\">";
        // line 125
        echo "<div class=\"eva\">Eva</div>
            </div>\t
        </div>
        <br>";
        // line 129
        echo "<div class=\"title-bar\" data-responsive-toggle=\"main-menu\" data-hide-for=\"medium\">
            <button class=\"menu-icon\" type=\"button\" data-toggle></button>
            <div class=\"title-bar-title\">Menu</div>
        </div>
        <div class=\"top-bar\" id=\"main-menu\">
            <div class=\"top-bar-left\">
                <ul class=\"menu\" data-responsive-menu=\"drilldown medium-dropdown\">
                    <li><a href=\"/main\" class=\"btn btn-sucess\">Página Principal</a></li>
                    <li><a href= ";
        // line 137
        $this->displayBlock('btn1href', $context, $blocks);
        echo " >";
        $this->displayBlock('btn1', $context, $blocks);
        echo "</a></li>
                    <li><a href= ";
        // line 138
        $this->displayBlock('btn2href', $context, $blocks);
        echo " class=\"btn btn-sucess\">";
        $this->displayBlock('btn2', $context, $blocks);
        echo "</a></li>
                    <li><a href= ";
        // line 139
        $this->displayBlock('btn3href', $context, $blocks);
        echo " class=\"btn btn-sucess\">";
        $this->displayBlock('btn3', $context, $blocks);
        echo "</a></li>
                    ";
        // line 140
        $this->displayBlock('btnAdicional', $context, $blocks);
        // line 141
        echo "                </ul>
            </div>
            <div class=\"top-bar-right\">
                <ul class=\"dropdown menu\" data-dropdown-menu>
                    <ul class=\"menu\">
                        <li>
                            <input type=\"search\" placeholder=\"Busquedas\">
                        </li>
                        <li>
                            <button type=\"button\" class=\"button\">Buscar</button>
                        </li>
                    </ul>
                </ul>
            </div>
        </div>";
        // line 156
        echo "</header>
    <br>
   
    <hr>
    <div class=\"row\">
        <div class=\"large-8 columns\" style=\"border-right: 1px solid #E3E5E8;\">
            ";
        // line 162
        $this->displayBlock('LeftColumn', $context, $blocks);
        // line 163
        echo "        </div>
        <div class=\"large-4 columns\">
            <aside>
                <div class=\"row column\">
                    ";
        // line 167
        $this->displayBlock('field', $context, $blocks);
        // line 168
        echo "                    <br>
                </div>
                <br>
                <hr>
                <div class=\"row small-up-3\">
                    <div class=\"column text-center\">
                        <i class=\"fi-social-facebook\"></i>
                        <a target=\"_blank\" href=\"https://www.facebook.com/GrupoLinuxUD/?fref=ts\">\tGrupo GNU/Linux UD</a>
                        <br>
                    </div>
                    <div class=\"column text-center\">
                        <i class=\"fi-social-twitter\"></i>
                        <a target=\"_blank\" href=\"https://twitter.com/grupolinuxud\">\tTwitter GLUD </a>
                        <br>
                    </div>
                    <div class=\"column text-center\">
                        <i class=\"fi-social-youtube\"></i>
                        <a target=\"_blank\" href=\"https://www.youtube.com/channel/UCWPIj_ZjOM94VRf4X2h_Kvg\">\tRadio GLUD </a>
                    </div>
                </div>

            </aside>
        </div>
    </div>
    <hr>
    <div class=\"row column\">
        <h3 style=\"text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'sans-serif', cursive; font-size:28px;\t\" class=\"text-center\"> Grupo de trabajo GNU / Linux <br>Universidad Distrital Francisco José de Caldas</h3S>
    </div>
    <hr>
    <footer>
        <div class=\"ten columns\">
            \t<ul class=\"nav-bar right\">
                    <div class=\"show-for-small\" style=\"background:#FFFFFF; padding:5px;\">
                    <div style=\"width:30%; margin-right:0%; float:left;\">
                    \t<a href=\"https://glud.org/\">
                        ";
        // line 204
        echo "                       <center><div class=\"kokopelli\"><img class=\"thumbnail\" src=\"https://fbcdn-sphotos-f-a.akamaihd.net/hphotos-ak-xaf1/v/t1.0-9/13015145_1154980181208412_6240606777766531522_n.png?oh=223129eb765f354192c497bbaa32b3bd&oe=57E16126&__gda__=1469991057_acfc660301bf3d8c3eb5f21f152d23d0\" width='250' alt=\"Logotipo del GLUD\"></center></div>
                        </a>
            \t\t</div>
                    <div style=\"width:30%; margin-right:0%; float:left;\">
              \t\t\t<p style=\"margin: 0; font-family: 'sans-serif'; font-size:20px;\" class=\"text-center\"> Sede Central <br> Edificio Alejandro<br>Suárez Copete. <br> Carrera 8 No. 40 Piso 2. <br> Bogotá, Colombia </p>
                        </a>
            \t\t</div>
                    <div style=\"width:30%; float:right;\">
                    \t<a href=\"http://rita.udistrital.edu.co/ingenieria/\">
                        ";
        // line 214
        echo "                           <div class=\"UD\"><img class=\"thumbnail\" src=\"https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-xpf1/v/t1.0-9/12507117_235679856763097_6091731505178560444_n.jpg?oh=be77cc1b10f7484cbf19216d8ababa00&oe=57AEA4AF&__gda__=1474701765_e6428e0762743f003e6432d176caa322\" alt=\"image of space dog\"></div>
                        </a>
            \t\t</div>
                    <div style=\"clear:both;\"></div>
                    </div>
              \t</ul>
            </div>
    </footer>
    <script src=\"https://code.jquery.com/jquery-2.1.4.min.js\"></script>
    <script src=\"http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.js\"></script>
    <script>
        \$(document).foundation();
    </script>
    <script type=\"text/javascript\" src=\"https://intercom.zurb.com/scripts/zcom.js\"></script>
    ";
        // line 228
        $this->displayBlock('javascripts', $context, $blocks);
        // line 229
        echo "</body>
</html>
";
        
        $__internal_97bbe62f4bab5a991ce01552014d6a644635f19a006485e6c6f2e2434392bdbb->leave($__internal_97bbe62f4bab5a991ce01552014d6a644635f19a006485e6c6f2e2434392bdbb_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_dd0ff9a38d111b703609465227b9c43863691bdce4682ec3cebfc98ea64f37a5 = $this->env->getExtension("native_profiler");
        $__internal_dd0ff9a38d111b703609465227b9c43863691bdce4682ec3cebfc98ea64f37a5->enter($__internal_dd0ff9a38d111b703609465227b9c43863691bdce4682ec3cebfc98ea64f37a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_dd0ff9a38d111b703609465227b9c43863691bdce4682ec3cebfc98ea64f37a5->leave($__internal_dd0ff9a38d111b703609465227b9c43863691bdce4682ec3cebfc98ea64f37a5_prof);

    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_03f475b72a861c8de942dc7eb176982a195a78ac5fdcd53574db471de3390b42 = $this->env->getExtension("native_profiler");
        $__internal_03f475b72a861c8de942dc7eb176982a195a78ac5fdcd53574db471de3390b42->enter($__internal_03f475b72a861c8de942dc7eb176982a195a78ac5fdcd53574db471de3390b42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_03f475b72a861c8de942dc7eb176982a195a78ac5fdcd53574db471de3390b42->leave($__internal_03f475b72a861c8de942dc7eb176982a195a78ac5fdcd53574db471de3390b42_prof);

    }

    // line 137
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_3d89e7a25bbd47afeef2aa4f23e31bd4f6e86f701e5edc788635191c40f36b71 = $this->env->getExtension("native_profiler");
        $__internal_3d89e7a25bbd47afeef2aa4f23e31bd4f6e86f701e5edc788635191c40f36b71->enter($__internal_3d89e7a25bbd47afeef2aa4f23e31bd4f6e86f701e5edc788635191c40f36b71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        echo " /";
        
        $__internal_3d89e7a25bbd47afeef2aa4f23e31bd4f6e86f701e5edc788635191c40f36b71->leave($__internal_3d89e7a25bbd47afeef2aa4f23e31bd4f6e86f701e5edc788635191c40f36b71_prof);

    }

    public function block_btn1($context, array $blocks = array())
    {
        $__internal_80ee0bc7e7d9d0381902e8d9bf3b592e536f8bfe8e86f564cc355e50b7c31646 = $this->env->getExtension("native_profiler");
        $__internal_80ee0bc7e7d9d0381902e8d9bf3b592e536f8bfe8e86f564cc355e50b7c31646->enter($__internal_80ee0bc7e7d9d0381902e8d9bf3b592e536f8bfe8e86f564cc355e50b7c31646_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        echo " ";
        
        $__internal_80ee0bc7e7d9d0381902e8d9bf3b592e536f8bfe8e86f564cc355e50b7c31646->leave($__internal_80ee0bc7e7d9d0381902e8d9bf3b592e536f8bfe8e86f564cc355e50b7c31646_prof);

    }

    // line 138
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_e5deb73db46aa7894345935508cfde923fec291f790fbc469a0f1ecfa20d2d8c = $this->env->getExtension("native_profiler");
        $__internal_e5deb73db46aa7894345935508cfde923fec291f790fbc469a0f1ecfa20d2d8c->enter($__internal_e5deb73db46aa7894345935508cfde923fec291f790fbc469a0f1ecfa20d2d8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        echo "/  ";
        
        $__internal_e5deb73db46aa7894345935508cfde923fec291f790fbc469a0f1ecfa20d2d8c->leave($__internal_e5deb73db46aa7894345935508cfde923fec291f790fbc469a0f1ecfa20d2d8c_prof);

    }

    public function block_btn2($context, array $blocks = array())
    {
        $__internal_9bf285d5dcdc58bcf7fad5dce549363627a6643ce3dd586c9d7dd9735b480e34 = $this->env->getExtension("native_profiler");
        $__internal_9bf285d5dcdc58bcf7fad5dce549363627a6643ce3dd586c9d7dd9735b480e34->enter($__internal_9bf285d5dcdc58bcf7fad5dce549363627a6643ce3dd586c9d7dd9735b480e34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        echo " ";
        
        $__internal_9bf285d5dcdc58bcf7fad5dce549363627a6643ce3dd586c9d7dd9735b480e34->leave($__internal_9bf285d5dcdc58bcf7fad5dce549363627a6643ce3dd586c9d7dd9735b480e34_prof);

    }

    // line 139
    public function block_btn3href($context, array $blocks = array())
    {
        $__internal_455040086f813411247fcd027c00071a8f466bfbdcc782fa43b5d9600ec53784 = $this->env->getExtension("native_profiler");
        $__internal_455040086f813411247fcd027c00071a8f466bfbdcc782fa43b5d9600ec53784->enter($__internal_455040086f813411247fcd027c00071a8f466bfbdcc782fa43b5d9600ec53784_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn3href"));

        echo "/  ";
        
        $__internal_455040086f813411247fcd027c00071a8f466bfbdcc782fa43b5d9600ec53784->leave($__internal_455040086f813411247fcd027c00071a8f466bfbdcc782fa43b5d9600ec53784_prof);

    }

    public function block_btn3($context, array $blocks = array())
    {
        $__internal_54889d7bc877d1fae31a7c26f42980907fce950e87fea3956db41446994f0872 = $this->env->getExtension("native_profiler");
        $__internal_54889d7bc877d1fae31a7c26f42980907fce950e87fea3956db41446994f0872->enter($__internal_54889d7bc877d1fae31a7c26f42980907fce950e87fea3956db41446994f0872_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn3"));

        echo "  ";
        
        $__internal_54889d7bc877d1fae31a7c26f42980907fce950e87fea3956db41446994f0872->leave($__internal_54889d7bc877d1fae31a7c26f42980907fce950e87fea3956db41446994f0872_prof);

    }

    // line 140
    public function block_btnAdicional($context, array $blocks = array())
    {
        $__internal_2e53c1453df41b9e715a0c0655f6055a9844c64bcb5433a3543dbb5ebeda18de = $this->env->getExtension("native_profiler");
        $__internal_2e53c1453df41b9e715a0c0655f6055a9844c64bcb5433a3543dbb5ebeda18de->enter($__internal_2e53c1453df41b9e715a0c0655f6055a9844c64bcb5433a3543dbb5ebeda18de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btnAdicional"));

        echo "  ";
        
        $__internal_2e53c1453df41b9e715a0c0655f6055a9844c64bcb5433a3543dbb5ebeda18de->leave($__internal_2e53c1453df41b9e715a0c0655f6055a9844c64bcb5433a3543dbb5ebeda18de_prof);

    }

    // line 162
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_9c18de73a9557e69d09add776bb5b7290ca248f4534b78aadaf476b0a283b8d9 = $this->env->getExtension("native_profiler");
        $__internal_9c18de73a9557e69d09add776bb5b7290ca248f4534b78aadaf476b0a283b8d9->enter($__internal_9c18de73a9557e69d09add776bb5b7290ca248f4534b78aadaf476b0a283b8d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        echo " Columna Izquierda ";
        
        $__internal_9c18de73a9557e69d09add776bb5b7290ca248f4534b78aadaf476b0a283b8d9->leave($__internal_9c18de73a9557e69d09add776bb5b7290ca248f4534b78aadaf476b0a283b8d9_prof);

    }

    // line 167
    public function block_field($context, array $blocks = array())
    {
        $__internal_9782766c98d00dd5bb0648faf302e9ba524cde480ac438eca19f7a7154c54a19 = $this->env->getExtension("native_profiler");
        $__internal_9782766c98d00dd5bb0648faf302e9ba524cde480ac438eca19f7a7154c54a19->enter($__internal_9782766c98d00dd5bb0648faf302e9ba524cde480ac438eca19f7a7154c54a19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        echo " ";
        
        $__internal_9782766c98d00dd5bb0648faf302e9ba524cde480ac438eca19f7a7154c54a19->leave($__internal_9782766c98d00dd5bb0648faf302e9ba524cde480ac438eca19f7a7154c54a19_prof);

    }

    // line 228
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_22df753a8790f6757bc81281e4af7d487ffd397bd71d7df154bc17b2ed7c373e = $this->env->getExtension("native_profiler");
        $__internal_22df753a8790f6757bc81281e4af7d487ffd397bd71d7df154bc17b2ed7c373e->enter($__internal_22df753a8790f6757bc81281e4af7d487ffd397bd71d7df154bc17b2ed7c373e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        echo "    ";
        
        $__internal_22df753a8790f6757bc81281e4af7d487ffd397bd71d7df154bc17b2ed7c373e->leave($__internal_22df753a8790f6757bc81281e4af7d487ffd397bd71d7df154bc17b2ed7c373e_prof);

    }

    public function getTemplateName()
    {
        return "evabase.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  434 => 228,  422 => 167,  410 => 162,  398 => 140,  375 => 139,  352 => 138,  329 => 137,  318 => 15,  307 => 7,  298 => 229,  296 => 228,  280 => 214,  269 => 204,  232 => 168,  230 => 167,  224 => 163,  222 => 162,  214 => 156,  198 => 141,  196 => 140,  190 => 139,  184 => 138,  178 => 137,  168 => 129,  163 => 125,  160 => 122,  55 => 16,  53 => 15,  42 => 7,  34 => 1,);
    }
}
/* <!doctype html>*/
/* <html class="no-js" lang="en">*/
/* */
/* <head>*/
/*     <meta charset="utf-8" />*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1.0" />*/
/*     <title> ~ Eva |{% block title %}{% endblock %}</title>*/
/*     <!--Inclusi�n de Fuentes, tomadas de:https://www.google.com/fonts/-->*/
/*     <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>*/
/*     <link href='https://fonts.googleapis.com/css?family=Calligraffitti' rel='stylesheet'>*/
/*     <link href='https://fonts.googleapis.com/css?family=sans-serif' rel='stylesheet' type='text/css'>*/
/*     <link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>*/
/* */
/*     <link rel="stylesheet" href="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">*/
/*     <link href='http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css' rel='stylesheet' type='text/css'> {% block stylesheets %}{% endblock %}*/
/*     <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/* </head>*/
/* */
/* <body>*/
/*     <style>*/
/*         .eva {*/
/*             -webkit-box-sizing: content-box;*/
/*             -moz-box-sizing: content-box;*/
/*             box-sizing: content-box;*/
/*             border: none;*/
/*             font: normal 130px/1 "cookie", 'Norican', sans-serif;*/
/*             color: rgba(0, 0, 0, 1);*/
/*             -o-text-overflow: ellipsis;*/
/*             text-overflow: ellipsis;*/
/*             background: rgb(255, 255, 255);*/
/*             text-shadow: 4px 4px 6px rgba(0, 155, 255, 0.8);*/
/*             -webkit-transform: rotateX(-32.65859432245692deg) rotateY(5.156620156177409deg);*/
/*             transform: rotateX(-32.65859432245692deg) rotateY(5.156620156177409deg);*/
/*         }*/
/* */
/* */
/* */
/*         .fi-social-facebook {*/
/*             color: dodgerblue;*/
/*             font-size: 2rem;*/
/*         }*/
/* */
/*         .fi-social-youtube {*/
/*             color: red;*/
/*             font-size: 2rem;*/
/*         }*/
/* */
/*         .fi-social-twitter {*/
/*             color: skyblue;*/
/*             font-size: 2rem;*/
/*         }*/
/* */
/*         body {*/
/*             margin-top: 2rem;*/
/*         }*/
/* */
/*         .title-bar {*/
/*             background: #333;*/
/*             padding: 0.9rem;*/
/*         }*/
/* */
/*         .top-bar {*/
/*             background: #333;*/
/*         }*/
/* */
/*         .top-bar ul {*/
/*             background: #333;*/
/*         }*/
/* */
/*         .top-bar ul li {*/
/*             background: #333;*/
/*         }*/
/* */
/*         .top-bar ul li a {*/
/*             color: #fff;*/
/*         }*/
/* */
/*         .menu-text {*/
/*             color: #fff;*/
/*         }*/
/* */
/*         @media only screen and (max-width: 40em) {*/
/*             .menu-text {*/
/*                 display: none !important;*/
/*             }*/
/*         }*/
/* */
/*         @media only screen and (min-width: 40em) {*/
/*             .top-bar .menu:last-child {*/
/*                 border-left: 1px solid #4e4e4e;*/
/*             }*/
/*             .top-bar .menu:first-child {*/
/*                 border-left: none;*/
/*             }*/
/*             .top-bar .menu li:not(:last-child) {*/
/*                 border-right: 1px solid #4e4e4e;*/
/*             }*/
/*         }*/
/* */
/*         .dropdown.menu .submenu {*/
/*             border: none;*/
/*         }*/
/* */
/*         .dropdown.menu .is-dropdown-submenu-parent.is-right-arrow > a::after {*/
/*             border-color: #fff transparent transparent;*/
/*         }*/
/* */
/*         .is-drilldown-submenu-parent > a::after {*/
/*             border-color: transparent transparent transparent #fff;*/
/*         }*/
/* */
/*         .js-drilldown-back::before {*/
/*             border-color: transparent #fff transparent transparent;*/
/*         }*/
/*     </style>*/
/*     <header>*/
/*         {#*/
/*         <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">*/
/*             <button class="menu-icon" type="button" data-toggle></button>*/
/*             <div class="title-bar-title">Menu</div>*/
/*         </div>#}*/
/*         <div class="row">*/
/*             <div class="medium columns expanded text-center">*/
/*                 {#- <img src="https://s-media-cache-ak0.pinimg.com/originals/91/34/23/913423498f0249fcf8d39f9301324e7f.png" alt="Error">-#}*/
/*                 <div class="eva">Eva</div>*/
/*             </div>	*/
/*         </div>*/
/*         <br> {#------#}*/
/*         <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">*/
/*             <button class="menu-icon" type="button" data-toggle></button>*/
/*             <div class="title-bar-title">Menu</div>*/
/*         </div>*/
/*         <div class="top-bar" id="main-menu">*/
/*             <div class="top-bar-left">*/
/*                 <ul class="menu" data-responsive-menu="drilldown medium-dropdown">*/
/*                     <li><a href="/main" class="btn btn-sucess">Página Principal</a></li>*/
/*                     <li><a href= {% block btn1href %} /{% endblock %} >{% block btn1 %} {% endblock %}</a></li>*/
/*                     <li><a href= {% block btn2href %}/  {% endblock %} class="btn btn-sucess">{% block btn2 %} {% endblock %}</a></li>*/
/*                     <li><a href= {% block btn3href %}/  {% endblock %} class="btn btn-sucess">{% block btn3 %}  {% endblock %}</a></li>*/
/*                     {% block btnAdicional %}  {% endblock %}*/
/*                 </ul>*/
/*             </div>*/
/*             <div class="top-bar-right">*/
/*                 <ul class="dropdown menu" data-dropdown-menu>*/
/*                     <ul class="menu">*/
/*                         <li>*/
/*                             <input type="search" placeholder="Busquedas">*/
/*                         </li>*/
/*                         <li>*/
/*                             <button type="button" class="button">Buscar</button>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </ul>*/
/*             </div>*/
/*         </div>{#--------#}*/
/*     </header>*/
/*     <br>*/
/*    */
/*     <hr>*/
/*     <div class="row">*/
/*         <div class="large-8 columns" style="border-right: 1px solid #E3E5E8;">*/
/*             {% block LeftColumn %} Columna Izquierda {% endblock %}*/
/*         </div>*/
/*         <div class="large-4 columns">*/
/*             <aside>*/
/*                 <div class="row column">*/
/*                     {% block field %} {% endblock %}*/
/*                     <br>*/
/*                 </div>*/
/*                 <br>*/
/*                 <hr>*/
/*                 <div class="row small-up-3">*/
/*                     <div class="column text-center">*/
/*                         <i class="fi-social-facebook"></i>*/
/*                         <a target="_blank" href="https://www.facebook.com/GrupoLinuxUD/?fref=ts">	Grupo GNU/Linux UD</a>*/
/*                         <br>*/
/*                     </div>*/
/*                     <div class="column text-center">*/
/*                         <i class="fi-social-twitter"></i>*/
/*                         <a target="_blank" href="https://twitter.com/grupolinuxud">	Twitter GLUD </a>*/
/*                         <br>*/
/*                     </div>*/
/*                     <div class="column text-center">*/
/*                         <i class="fi-social-youtube"></i>*/
/*                         <a target="_blank" href="https://www.youtube.com/channel/UCWPIj_ZjOM94VRf4X2h_Kvg">	Radio GLUD </a>*/
/*                     </div>*/
/*                 </div>*/
/* */
/*             </aside>*/
/*         </div>*/
/*     </div>*/
/*     <hr>*/
/*     <div class="row column">*/
/*         <h3 style="text-shadow: 4px 4px 6px rgba(100, 155, 255, 0.8); margin: 20; font-family: 'sans-serif', cursive; font-size:28px;	" class="text-center"> Grupo de trabajo GNU / Linux <br>Universidad Distrital Francisco José de Caldas</h3S>*/
/*     </div>*/
/*     <hr>*/
/*     <footer>*/
/*         <div class="ten columns">*/
/*             	<ul class="nav-bar right">*/
/*                     <div class="show-for-small" style="background:#FFFFFF; padding:5px;">*/
/*                     <div style="width:30%; margin-right:0%; float:left;">*/
/*                     	<a href="https://glud.org/">*/
/*                         {# Logo Glud #}*/
/*                        <center><div class="kokopelli"><img class="thumbnail" src="https://fbcdn-sphotos-f-a.akamaihd.net/hphotos-ak-xaf1/v/t1.0-9/13015145_1154980181208412_6240606777766531522_n.png?oh=223129eb765f354192c497bbaa32b3bd&oe=57E16126&__gda__=1469991057_acfc660301bf3d8c3eb5f21f152d23d0" width='250' alt="Logotipo del GLUD"></center></div>*/
/*                         </a>*/
/*             		</div>*/
/*                     <div style="width:30%; margin-right:0%; float:left;">*/
/*               			<p style="margin: 0; font-family: 'sans-serif'; font-size:20px;" class="text-center"> Sede Central <br> Edificio Alejandro<br>Suárez Copete. <br> Carrera 8 No. 40 Piso 2. <br> Bogotá, Colombia </p>*/
/*                         </a>*/
/*             		</div>*/
/*                     <div style="width:30%; float:right;">*/
/*                     	<a href="http://rita.udistrital.edu.co/ingenieria/">*/
/*                         {# Logo UD #}*/
/*                            <div class="UD"><img class="thumbnail" src="https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-xpf1/v/t1.0-9/12507117_235679856763097_6091731505178560444_n.jpg?oh=be77cc1b10f7484cbf19216d8ababa00&oe=57AEA4AF&__gda__=1474701765_e6428e0762743f003e6432d176caa322" alt="image of space dog"></div>*/
/*                         </a>*/
/*             		</div>*/
/*                     <div style="clear:both;"></div>*/
/*                     </div>*/
/*               	</ul>*/
/*             </div>*/
/*     </footer>*/
/*     <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>*/
/*     <script src="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.js"></script>*/
/*     <script>*/
/*         $(document).foundation();*/
/*     </script>*/
/*     <script type="text/javascript" src="https://intercom.zurb.com/scripts/zcom.js"></script>*/
/*     {% block javascripts %}    {% endblock %}*/
/* </body>*/
/* </html>*/
/* */
