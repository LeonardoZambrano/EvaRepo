<?php

/* eva/docente.html.twig */
class __TwigTemplate_57e4be4d39458f30168ef7fb929c7490ce13d3940583ba471336ee07c5057c4b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/docente.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'field' => array($this, 'block_field'),
            'field1' => array($this, 'block_field1'),
            'field2' => array($this, 'block_field2'),
            'field3' => array($this, 'block_field3'),
            'field4' => array($this, 'block_field4'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btn3href' => array($this, 'block_btn3href'),
            'btn3' => array($this, 'block_btn3'),
            'subtitle' => array($this, 'block_subtitle'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ac281532de623bfc7cc71720a60cd40616739a6ae6f3e0b7bf51d8624548712 = $this->env->getExtension("native_profiler");
        $__internal_3ac281532de623bfc7cc71720a60cd40616739a6ae6f3e0b7bf51d8624548712->enter($__internal_3ac281532de623bfc7cc71720a60cd40616739a6ae6f3e0b7bf51d8624548712_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/docente.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3ac281532de623bfc7cc71720a60cd40616739a6ae6f3e0b7bf51d8624548712->leave($__internal_3ac281532de623bfc7cc71720a60cd40616739a6ae6f3e0b7bf51d8624548712_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_ce17e3503f3480227bae520d5ec28af6f91bdc23129dd17dba26030a60f2e4ef = $this->env->getExtension("native_profiler");
        $__internal_ce17e3503f3480227bae520d5ec28af6f91bdc23129dd17dba26030a60f2e4ef->enter($__internal_ce17e3503f3480227bae520d5ec28af6f91bdc23129dd17dba26030a60f2e4ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Docente";
        
        $__internal_ce17e3503f3480227bae520d5ec28af6f91bdc23129dd17dba26030a60f2e4ef->leave($__internal_ce17e3503f3480227bae520d5ec28af6f91bdc23129dd17dba26030a60f2e4ef_prof);

    }

    // line 3
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_f4baaaa9ee04d512e01841ce39783501ed1222810014e9a04c804a53868c03d7 = $this->env->getExtension("native_profiler");
        $__internal_f4baaaa9ee04d512e01841ce39783501ed1222810014e9a04c804a53868c03d7->enter($__internal_f4baaaa9ee04d512e01841ce39783501ed1222810014e9a04c804a53868c03d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        $this->displayParentBlock("titulo", $context, $blocks);
        
        $__internal_f4baaaa9ee04d512e01841ce39783501ed1222810014e9a04c804a53868c03d7->leave($__internal_f4baaaa9ee04d512e01841ce39783501ed1222810014e9a04c804a53868c03d7_prof);

    }

    // line 4
    public function block_field($context, array $blocks = array())
    {
        $__internal_e44a64087b5509115898e05b4a51c413902b6bfe83ad93223ca7528864e0ba01 = $this->env->getExtension("native_profiler");
        $__internal_e44a64087b5509115898e05b4a51c413902b6bfe83ad93223ca7528864e0ba01->enter($__internal_e44a64087b5509115898e05b4a51c413902b6bfe83ad93223ca7528864e0ba01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        
        $__internal_e44a64087b5509115898e05b4a51c413902b6bfe83ad93223ca7528864e0ba01->leave($__internal_e44a64087b5509115898e05b4a51c413902b6bfe83ad93223ca7528864e0ba01_prof);

    }

    // line 6
    public function block_field1($context, array $blocks = array())
    {
        $__internal_16dec29a71899c37326c53176fe9ca21f77a1fc480ac3d2f3276861423016973 = $this->env->getExtension("native_profiler");
        $__internal_16dec29a71899c37326c53176fe9ca21f77a1fc480ac3d2f3276861423016973->enter($__internal_16dec29a71899c37326c53176fe9ca21f77a1fc480ac3d2f3276861423016973_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field1"));

        // line 7
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
        
        $__internal_16dec29a71899c37326c53176fe9ca21f77a1fc480ac3d2f3276861423016973->leave($__internal_16dec29a71899c37326c53176fe9ca21f77a1fc480ac3d2f3276861423016973_prof);

    }

    // line 11
    public function block_field2($context, array $blocks = array())
    {
        $__internal_2d8044cdac8cc61e051c37b65fadcd4ee5e0bf81606417c622d1280f58c295bd = $this->env->getExtension("native_profiler");
        $__internal_2d8044cdac8cc61e051c37b65fadcd4ee5e0bf81606417c622d1280f58c295bd->enter($__internal_2d8044cdac8cc61e051c37b65fadcd4ee5e0bf81606417c622d1280f58c295bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field2"));

        // line 12
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
        
        $__internal_2d8044cdac8cc61e051c37b65fadcd4ee5e0bf81606417c622d1280f58c295bd->leave($__internal_2d8044cdac8cc61e051c37b65fadcd4ee5e0bf81606417c622d1280f58c295bd_prof);

    }

    // line 16
    public function block_field3($context, array $blocks = array())
    {
        $__internal_3c7a040ad1ec203cbcc3137426806e6d5999fbc5d4181fcceb680c80e247b3d0 = $this->env->getExtension("native_profiler");
        $__internal_3c7a040ad1ec203cbcc3137426806e6d5999fbc5d4181fcceb680c80e247b3d0->enter($__internal_3c7a040ad1ec203cbcc3137426806e6d5999fbc5d4181fcceb680c80e247b3d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field3"));

        // line 17
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
        
        $__internal_3c7a040ad1ec203cbcc3137426806e6d5999fbc5d4181fcceb680c80e247b3d0->leave($__internal_3c7a040ad1ec203cbcc3137426806e6d5999fbc5d4181fcceb680c80e247b3d0_prof);

    }

    // line 21
    public function block_field4($context, array $blocks = array())
    {
        $__internal_23b31fe554c703b1426377eb75272bfb6f8b8b594ea545e7e7d72f871797f21d = $this->env->getExtension("native_profiler");
        $__internal_23b31fe554c703b1426377eb75272bfb6f8b8b594ea545e7e7d72f871797f21d->enter($__internal_23b31fe554c703b1426377eb75272bfb6f8b8b594ea545e7e7d72f871797f21d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field4"));

        // line 22
        echo "    <img style=\"max-width:100px; max-height:100px;\" class=\"thumbnail\" src=\"https://upload.wikimedia.org/wikipedia/commons/3/35/Tux.svg\">
    Linux
";
        
        $__internal_23b31fe554c703b1426377eb75272bfb6f8b8b594ea545e7e7d72f871797f21d->leave($__internal_23b31fe554c703b1426377eb75272bfb6f8b8b594ea545e7e7d72f871797f21d_prof);

    }

    // line 25
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_b687d3bff733125fb86d26fff65e97983e16c8bc3cd2aa109f25bf2a58dd89a6 = $this->env->getExtension("native_profiler");
        $__internal_b687d3bff733125fb86d26fff65e97983e16c8bc3cd2aa109f25bf2a58dd89a6->enter($__internal_b687d3bff733125fb86d26fff65e97983e16c8bc3cd2aa109f25bf2a58dd89a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        // line 26
        echo "    Porfavor, seleccione alguna de las opciones presentadas en la parte superior.
    <link href=\"http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css\" rel=\"stylesheet\">
";
        
        $__internal_b687d3bff733125fb86d26fff65e97983e16c8bc3cd2aa109f25bf2a58dd89a6->leave($__internal_b687d3bff733125fb86d26fff65e97983e16c8bc3cd2aa109f25bf2a58dd89a6_prof);

    }

    // line 30
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_1eb481acc99c9c3fbf672c2f4776d3a9f0d80346ec9f88189288d87f9b1641ac = $this->env->getExtension("native_profiler");
        $__internal_1eb481acc99c9c3fbf672c2f4776d3a9f0d80346ec9f88189288d87f9b1641ac->enter($__internal_1eb481acc99c9c3fbf672c2f4776d3a9f0d80346ec9f88189288d87f9b1641ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        // line 31
        echo "    /ListaExamenes
";
        
        $__internal_1eb481acc99c9c3fbf672c2f4776d3a9f0d80346ec9f88189288d87f9b1641ac->leave($__internal_1eb481acc99c9c3fbf672c2f4776d3a9f0d80346ec9f88189288d87f9b1641ac_prof);

    }

    // line 33
    public function block_btn1($context, array $blocks = array())
    {
        $__internal_4674ca2f0670cfcd9ca4a9b24fa806abc6fe0648213411df881ee59d0930fd8f = $this->env->getExtension("native_profiler");
        $__internal_4674ca2f0670cfcd9ca4a9b24fa806abc6fe0648213411df881ee59d0930fd8f->enter($__internal_4674ca2f0670cfcd9ca4a9b24fa806abc6fe0648213411df881ee59d0930fd8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        echo "Examenes Creados
";
        
        $__internal_4674ca2f0670cfcd9ca4a9b24fa806abc6fe0648213411df881ee59d0930fd8f->leave($__internal_4674ca2f0670cfcd9ca4a9b24fa806abc6fe0648213411df881ee59d0930fd8f_prof);

    }

    // line 36
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_e51f3326c4adeef1bc3d22b705a4013f8f144500eaa56f5e3fe541e5bba02e77 = $this->env->getExtension("native_profiler");
        $__internal_e51f3326c4adeef1bc3d22b705a4013f8f144500eaa56f5e3fe541e5bba02e77->enter($__internal_e51f3326c4adeef1bc3d22b705a4013f8f144500eaa56f5e3fe541e5bba02e77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        // line 37
        echo "    /createExam
";
        
        $__internal_e51f3326c4adeef1bc3d22b705a4013f8f144500eaa56f5e3fe541e5bba02e77->leave($__internal_e51f3326c4adeef1bc3d22b705a4013f8f144500eaa56f5e3fe541e5bba02e77_prof);

    }

    // line 39
    public function block_btn2($context, array $blocks = array())
    {
        $__internal_00d470d551aeef4e1102f9da8da2c1477d224e1036475e207fb0e988ab548966 = $this->env->getExtension("native_profiler");
        $__internal_00d470d551aeef4e1102f9da8da2c1477d224e1036475e207fb0e988ab548966->enter($__internal_00d470d551aeef4e1102f9da8da2c1477d224e1036475e207fb0e988ab548966_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        // line 40
        echo "    Crear Examen";
        
        $__internal_00d470d551aeef4e1102f9da8da2c1477d224e1036475e207fb0e988ab548966->leave($__internal_00d470d551aeef4e1102f9da8da2c1477d224e1036475e207fb0e988ab548966_prof);

    }

    // line 42
    public function block_btn3href($context, array $blocks = array())
    {
        $__internal_b9d0e4bdb7fce1ef62ad4dc5ce6b97a373d1be1780ab6367c82e675cba53ccbc = $this->env->getExtension("native_profiler");
        $__internal_b9d0e4bdb7fce1ef62ad4dc5ce6b97a373d1be1780ab6367c82e675cba53ccbc->enter($__internal_b9d0e4bdb7fce1ef62ad4dc5ce6b97a373d1be1780ab6367c82e675cba53ccbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn3href"));

        
        $__internal_b9d0e4bdb7fce1ef62ad4dc5ce6b97a373d1be1780ab6367c82e675cba53ccbc->leave($__internal_b9d0e4bdb7fce1ef62ad4dc5ce6b97a373d1be1780ab6367c82e675cba53ccbc_prof);

    }

    // line 43
    public function block_btn3($context, array $blocks = array())
    {
        $__internal_37996f44864458468fadd39d9c877826ac7ee5a4be2b88dfc054bc59e282583d = $this->env->getExtension("native_profiler");
        $__internal_37996f44864458468fadd39d9c877826ac7ee5a4be2b88dfc054bc59e282583d->enter($__internal_37996f44864458468fadd39d9c877826ac7ee5a4be2b88dfc054bc59e282583d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn3"));

        echo "Añadir Estudiante
";
        
        $__internal_37996f44864458468fadd39d9c877826ac7ee5a4be2b88dfc054bc59e282583d->leave($__internal_37996f44864458468fadd39d9c877826ac7ee5a4be2b88dfc054bc59e282583d_prof);

    }

    // line 45
    public function block_subtitle($context, array $blocks = array())
    {
        $__internal_ef8f49d55329354e8a7e7cbca915847d715acc7be53eaec114789c555851a296 = $this->env->getExtension("native_profiler");
        $__internal_ef8f49d55329354e8a7e7cbca915847d715acc7be53eaec114789c555851a296->enter($__internal_ef8f49d55329354e8a7e7cbca915847d715acc7be53eaec114789c555851a296_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subtitle"));

        
        $__internal_ef8f49d55329354e8a7e7cbca915847d715acc7be53eaec114789c555851a296->leave($__internal_ef8f49d55329354e8a7e7cbca915847d715acc7be53eaec114789c555851a296_prof);

    }

    // line 47
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_9b1bd2683d9758690e6c2565368f86fdaad1ffffe903210e928fae099219f243 = $this->env->getExtension("native_profiler");
        $__internal_9b1bd2683d9758690e6c2565368f86fdaad1ffffe903210e928fae099219f243->enter($__internal_9b1bd2683d9758690e6c2565368f86fdaad1ffffe903210e928fae099219f243_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 48
        echo "    <style>
        .log-in-form {
            border: 1px solid #cacaca;
            padding: 1rem;
            border-radius: 3px;
        }
        .header {
            text-align: center;
            background: #000000;
            background-size: cover;
            padding: 4rem;
        }
        .header .main-header {
            color: #666;
        }

        .header-subnav {
            float: none;
            position: relative;
            top: 4rem;
            text-align: center;
            margin-bottom: 0;
        }
        .header-subnav li {
            float: none;
            display: inline-block;
        }
        .header-subnav li a {
            padding: 0.9rem 1rem 0.75rem;
            font-size: 0.875rem;
            color: #fff;
            text-transform: uppercase;
            display: block;
            font-weight: bold;
            letter-spacing: 1px;
        }
        .header-subnav li a.is-active {
            background: rgba(250, 250, 250, 0.7);
            color: #333;
        }
        .header-subnav li a:hover {
            background: rgba(250, 250, 250, 0.7);
            color: #333;
            transition: all 0.25s ease-in-out;
        }

    </style>
";
        
        $__internal_9b1bd2683d9758690e6c2565368f86fdaad1ffffe903210e928fae099219f243->leave($__internal_9b1bd2683d9758690e6c2565368f86fdaad1ffffe903210e928fae099219f243_prof);

    }

    public function getTemplateName()
    {
        return "eva/docente.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 48,  251 => 47,  240 => 45,  227 => 43,  216 => 42,  209 => 40,  203 => 39,  195 => 37,  189 => 36,  176 => 33,  168 => 31,  162 => 30,  153 => 26,  147 => 25,  138 => 22,  132 => 21,  122 => 17,  116 => 16,  106 => 12,  100 => 11,  90 => 7,  84 => 6,  73 => 4,  61 => 3,  49 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}Docente{% endblock %}{#Titulo barra navegador#}*/
/* {% block titulo %}{{parent()}}{% endblock %}{#Titulo interno página#}*/
/* {% block field %}{% endblock %}{#Primer Texto Columna Izq#}*/
/* {#  Adición de imagenes por campo en la plantilla #}*/
/* {% block field1 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field2 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field3 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field4 %}*/
/*     <img style="max-width:100px; max-height:100px;" class="thumbnail" src="https://upload.wikimedia.org/wikipedia/commons/3/35/Tux.svg">*/
/*     Linux*/
/* {% endblock %}*/
/* {% block LeftColumn %}*/
/*     Porfavor, seleccione alguna de las opciones presentadas en la parte superior.*/
/*     <link href="http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css" rel="stylesheet">*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /ListaExamenes*/
/* {% endblock %}*/
/* {% block btn1 %}Examenes Creados*/
/* {% endblock %}*/
/* */
/* {% block btn2href %}*/
/*     /createExam*/
/* {% endblock %}*/
/* {% block btn2 %}*/
/*     Crear Examen{% endblock %}*/
/* */
/* {% block btn3href %}{% endblock %}*/
/* {% block btn3 %}Añadir Estudiante*/
/* {% endblock %}*/
/* {% block subtitle %}{% endblock %}*/
/* */
/* {% block stylesheets %}*/
/*     <style>*/
/*         .log-in-form {*/
/*             border: 1px solid #cacaca;*/
/*             padding: 1rem;*/
/*             border-radius: 3px;*/
/*         }*/
/*         .header {*/
/*             text-align: center;*/
/*             background: #000000;*/
/*             background-size: cover;*/
/*             padding: 4rem;*/
/*         }*/
/*         .header .main-header {*/
/*             color: #666;*/
/*         }*/
/* */
/*         .header-subnav {*/
/*             float: none;*/
/*             position: relative;*/
/*             top: 4rem;*/
/*             text-align: center;*/
/*             margin-bottom: 0;*/
/*         }*/
/*         .header-subnav li {*/
/*             float: none;*/
/*             display: inline-block;*/
/*         }*/
/*         .header-subnav li a {*/
/*             padding: 0.9rem 1rem 0.75rem;*/
/*             font-size: 0.875rem;*/
/*             color: #fff;*/
/*             text-transform: uppercase;*/
/*             display: block;*/
/*             font-weight: bold;*/
/*             letter-spacing: 1px;*/
/*         }*/
/*         .header-subnav li a.is-active {*/
/*             background: rgba(250, 250, 250, 0.7);*/
/*             color: #333;*/
/*         }*/
/*         .header-subnav li a:hover {*/
/*             background: rgba(250, 250, 250, 0.7);*/
/*             color: #333;*/
/*             transition: all 0.25s ease-in-out;*/
/*         }*/
/* */
/*     </style>*/
/* {% endblock %}*/
/* */
