<?php

/* eva/plantilla.html.twig */
class __TwigTemplate_1b4271780e6837eaf2095c7b26d278706de94c6581f36303a759e145b8ece993 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/plantilla.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3219c32364d6bb159ddf03eb3ad85ab71d1622a68368e694504c37c07bd4db7a = $this->env->getExtension("native_profiler");
        $__internal_3219c32364d6bb159ddf03eb3ad85ab71d1622a68368e694504c37c07bd4db7a->enter($__internal_3219c32364d6bb159ddf03eb3ad85ab71d1622a68368e694504c37c07bd4db7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/plantilla.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3219c32364d6bb159ddf03eb3ad85ab71d1622a68368e694504c37c07bd4db7a->leave($__internal_3219c32364d6bb159ddf03eb3ad85ab71d1622a68368e694504c37c07bd4db7a_prof);

    }

    public function getTemplateName()
    {
        return "eva/plantilla.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* */
/* {# Visualización del Layout #}*/
/* */
