<?php

/* base.html.twig */
class __TwigTemplate_90683b1b36575aa7097ec7ba3b4bcd446736d6020fb62836579fbe8050a7773c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_308f2f1ea262354afb7d7b93cebd59c85e54246b47f7339f4c27df190d7c530c = $this->env->getExtension("native_profiler");
        $__internal_308f2f1ea262354afb7d7b93cebd59c85e54246b47f7339f4c27df190d7c530c->enter($__internal_308f2f1ea262354afb7d7b93cebd59c85e54246b47f7339f4c27df190d7c530c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_308f2f1ea262354afb7d7b93cebd59c85e54246b47f7339f4c27df190d7c530c->leave($__internal_308f2f1ea262354afb7d7b93cebd59c85e54246b47f7339f4c27df190d7c530c_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_32f611b8c6bf8248b72d5fe1778c3452fc9b308b216ace188a0c87fce233ef78 = $this->env->getExtension("native_profiler");
        $__internal_32f611b8c6bf8248b72d5fe1778c3452fc9b308b216ace188a0c87fce233ef78->enter($__internal_32f611b8c6bf8248b72d5fe1778c3452fc9b308b216ace188a0c87fce233ef78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_32f611b8c6bf8248b72d5fe1778c3452fc9b308b216ace188a0c87fce233ef78->leave($__internal_32f611b8c6bf8248b72d5fe1778c3452fc9b308b216ace188a0c87fce233ef78_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_fc0379c703c07ea1183ecfaa16ea04e2bb0a519c5cc4e365019fcfe3b0deec81 = $this->env->getExtension("native_profiler");
        $__internal_fc0379c703c07ea1183ecfaa16ea04e2bb0a519c5cc4e365019fcfe3b0deec81->enter($__internal_fc0379c703c07ea1183ecfaa16ea04e2bb0a519c5cc4e365019fcfe3b0deec81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_fc0379c703c07ea1183ecfaa16ea04e2bb0a519c5cc4e365019fcfe3b0deec81->leave($__internal_fc0379c703c07ea1183ecfaa16ea04e2bb0a519c5cc4e365019fcfe3b0deec81_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_847e899b3a1bd197eecb81ac09352a55cdfa644893961ee85999e1dc88e97e07 = $this->env->getExtension("native_profiler");
        $__internal_847e899b3a1bd197eecb81ac09352a55cdfa644893961ee85999e1dc88e97e07->enter($__internal_847e899b3a1bd197eecb81ac09352a55cdfa644893961ee85999e1dc88e97e07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_847e899b3a1bd197eecb81ac09352a55cdfa644893961ee85999e1dc88e97e07->leave($__internal_847e899b3a1bd197eecb81ac09352a55cdfa644893961ee85999e1dc88e97e07_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_90300c74a1b1992ccd7c4d9a213161c7076a49a643d1c9d16474dac5dca24532 = $this->env->getExtension("native_profiler");
        $__internal_90300c74a1b1992ccd7c4d9a213161c7076a49a643d1c9d16474dac5dca24532->enter($__internal_90300c74a1b1992ccd7c4d9a213161c7076a49a643d1c9d16474dac5dca24532_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_90300c74a1b1992ccd7c4d9a213161c7076a49a643d1c9d16474dac5dca24532->leave($__internal_90300c74a1b1992ccd7c4d9a213161c7076a49a643d1c9d16474dac5dca24532_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
