<?php

/* eva/invitado.html.twig */
class __TwigTemplate_3940f363777ff5b2bfdc2c5dd5b21c7b702c90b7fdb3e4d518d21121ed5643a4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/invitado.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ac40d3bba9e0cc30190b8c0f666f2a950ca4780869b5a24e304708fb813ed90c = $this->env->getExtension("native_profiler");
        $__internal_ac40d3bba9e0cc30190b8c0f666f2a950ca4780869b5a24e304708fb813ed90c->enter($__internal_ac40d3bba9e0cc30190b8c0f666f2a950ca4780869b5a24e304708fb813ed90c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/invitado.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ac40d3bba9e0cc30190b8c0f666f2a950ca4780869b5a24e304708fb813ed90c->leave($__internal_ac40d3bba9e0cc30190b8c0f666f2a950ca4780869b5a24e304708fb813ed90c_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_c42f74328aaf6a354f0a3928afbb68bc048621010a3b40dac4e268bb348c0b9c = $this->env->getExtension("native_profiler");
        $__internal_c42f74328aaf6a354f0a3928afbb68bc048621010a3b40dac4e268bb348c0b9c->enter($__internal_c42f74328aaf6a354f0a3928afbb68bc048621010a3b40dac4e268bb348c0b9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Cursos ";
        
        $__internal_c42f74328aaf6a354f0a3928afbb68bc048621010a3b40dac4e268bb348c0b9c->leave($__internal_c42f74328aaf6a354f0a3928afbb68bc048621010a3b40dac4e268bb348c0b9c_prof);

    }

    // line 3
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_24c4a0da3d9f38504ded6c633d9aa133b507ba372f11cad5b9578b36bee8e9a5 = $this->env->getExtension("native_profiler");
        $__internal_24c4a0da3d9f38504ded6c633d9aa133b507ba372f11cad5b9578b36bee8e9a5->enter($__internal_24c4a0da3d9f38504ded6c633d9aa133b507ba372f11cad5b9578b36bee8e9a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        // line 4
        echo "
";
        
        $__internal_24c4a0da3d9f38504ded6c633d9aa133b507ba372f11cad5b9578b36bee8e9a5->leave($__internal_24c4a0da3d9f38504ded6c633d9aa133b507ba372f11cad5b9578b36bee8e9a5_prof);

    }

    public function getTemplateName()
    {
        return "eva/invitado.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 4,  47 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}Cursos {% endblock %}*/
/* {% block LeftColumn %}*/
/* */
/* {% endblock %}*/
/* */
