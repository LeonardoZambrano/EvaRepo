<?php

/* eva/docente.html.twig */
class __TwigTemplate_156192a34fa900aee705680c2caa8d13ea88523c5f9c954226d44125f81febae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("evabase.html.twig", "eva/docente.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'titulo' => array($this, 'block_titulo'),
            'field' => array($this, 'block_field'),
            'field1' => array($this, 'block_field1'),
            'field2' => array($this, 'block_field2'),
            'field3' => array($this, 'block_field3'),
            'field4' => array($this, 'block_field4'),
            'LeftColumn' => array($this, 'block_LeftColumn'),
            'btn1href' => array($this, 'block_btn1href'),
            'btn1' => array($this, 'block_btn1'),
            'btn2href' => array($this, 'block_btn2href'),
            'btn2' => array($this, 'block_btn2'),
            'btn3href' => array($this, 'block_btn3href'),
            'btn3' => array($this, 'block_btn3'),
            'subtitle' => array($this, 'block_subtitle'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "evabase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a3049c47ebd760155b3ac0936f61ad95158c331166bec9c607e724d2ef8469de = $this->env->getExtension("native_profiler");
        $__internal_a3049c47ebd760155b3ac0936f61ad95158c331166bec9c607e724d2ef8469de->enter($__internal_a3049c47ebd760155b3ac0936f61ad95158c331166bec9c607e724d2ef8469de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eva/docente.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a3049c47ebd760155b3ac0936f61ad95158c331166bec9c607e724d2ef8469de->leave($__internal_a3049c47ebd760155b3ac0936f61ad95158c331166bec9c607e724d2ef8469de_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_d73286eddb4c7468b38f609abef5994227aea7ceb6e63a4ee25fa2b446bc6023 = $this->env->getExtension("native_profiler");
        $__internal_d73286eddb4c7468b38f609abef5994227aea7ceb6e63a4ee25fa2b446bc6023->enter($__internal_d73286eddb4c7468b38f609abef5994227aea7ceb6e63a4ee25fa2b446bc6023_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Docente";
        
        $__internal_d73286eddb4c7468b38f609abef5994227aea7ceb6e63a4ee25fa2b446bc6023->leave($__internal_d73286eddb4c7468b38f609abef5994227aea7ceb6e63a4ee25fa2b446bc6023_prof);

    }

    // line 3
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_662da79e20e673f2dc5c156f48cd5786d91cd0301a7a3b01835a20aa046d129f = $this->env->getExtension("native_profiler");
        $__internal_662da79e20e673f2dc5c156f48cd5786d91cd0301a7a3b01835a20aa046d129f->enter($__internal_662da79e20e673f2dc5c156f48cd5786d91cd0301a7a3b01835a20aa046d129f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        $this->displayParentBlock("titulo", $context, $blocks);
        
        $__internal_662da79e20e673f2dc5c156f48cd5786d91cd0301a7a3b01835a20aa046d129f->leave($__internal_662da79e20e673f2dc5c156f48cd5786d91cd0301a7a3b01835a20aa046d129f_prof);

    }

    // line 4
    public function block_field($context, array $blocks = array())
    {
        $__internal_2d713e3358f7b1f96bc5473b154f95ed66c024e1a98b15dd03c61ddbdf0aa537 = $this->env->getExtension("native_profiler");
        $__internal_2d713e3358f7b1f96bc5473b154f95ed66c024e1a98b15dd03c61ddbdf0aa537->enter($__internal_2d713e3358f7b1f96bc5473b154f95ed66c024e1a98b15dd03c61ddbdf0aa537_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        
        $__internal_2d713e3358f7b1f96bc5473b154f95ed66c024e1a98b15dd03c61ddbdf0aa537->leave($__internal_2d713e3358f7b1f96bc5473b154f95ed66c024e1a98b15dd03c61ddbdf0aa537_prof);

    }

    // line 6
    public function block_field1($context, array $blocks = array())
    {
        $__internal_0843feba186dba6409f98ffe6603de958c75edab4a3042f688b40be74bcaa27b = $this->env->getExtension("native_profiler");
        $__internal_0843feba186dba6409f98ffe6603de958c75edab4a3042f688b40be74bcaa27b->enter($__internal_0843feba186dba6409f98ffe6603de958c75edab4a3042f688b40be74bcaa27b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field1"));

        // line 7
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
        
        $__internal_0843feba186dba6409f98ffe6603de958c75edab4a3042f688b40be74bcaa27b->leave($__internal_0843feba186dba6409f98ffe6603de958c75edab4a3042f688b40be74bcaa27b_prof);

    }

    // line 11
    public function block_field2($context, array $blocks = array())
    {
        $__internal_b2766ea1075cf43bbab9b2dfb05ab3df9b6a42c854f3f2e6f95b24ab9ad6536b = $this->env->getExtension("native_profiler");
        $__internal_b2766ea1075cf43bbab9b2dfb05ab3df9b6a42c854f3f2e6f95b24ab9ad6536b->enter($__internal_b2766ea1075cf43bbab9b2dfb05ab3df9b6a42c854f3f2e6f95b24ab9ad6536b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field2"));

        // line 12
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
        
        $__internal_b2766ea1075cf43bbab9b2dfb05ab3df9b6a42c854f3f2e6f95b24ab9ad6536b->leave($__internal_b2766ea1075cf43bbab9b2dfb05ab3df9b6a42c854f3f2e6f95b24ab9ad6536b_prof);

    }

    // line 16
    public function block_field3($context, array $blocks = array())
    {
        $__internal_9633dd2b05a83c016b9ff8bcae65f240ff237f0a359ca7f312c30245ef4afaaa = $this->env->getExtension("native_profiler");
        $__internal_9633dd2b05a83c016b9ff8bcae65f240ff237f0a359ca7f312c30245ef4afaaa->enter($__internal_9633dd2b05a83c016b9ff8bcae65f240ff237f0a359ca7f312c30245ef4afaaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field3"));

        // line 17
        echo "    <div class=\"media-object-section\">
        <img class=\"thumbnail\" src=\"http://placehold.it/100\">
    </div>
";
        
        $__internal_9633dd2b05a83c016b9ff8bcae65f240ff237f0a359ca7f312c30245ef4afaaa->leave($__internal_9633dd2b05a83c016b9ff8bcae65f240ff237f0a359ca7f312c30245ef4afaaa_prof);

    }

    // line 21
    public function block_field4($context, array $blocks = array())
    {
        $__internal_abc5370f82133baead9c396dff6dde8ce73376073ae2e1ad3c00d30e477a3ca7 = $this->env->getExtension("native_profiler");
        $__internal_abc5370f82133baead9c396dff6dde8ce73376073ae2e1ad3c00d30e477a3ca7->enter($__internal_abc5370f82133baead9c396dff6dde8ce73376073ae2e1ad3c00d30e477a3ca7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field4"));

        // line 22
        echo "    <img style=\"max-width:100px; max-height:100px;\" class=\"thumbnail\" src=\"https://upload.wikimedia.org/wikipedia/commons/3/35/Tux.svg\">
    Linux
";
        
        $__internal_abc5370f82133baead9c396dff6dde8ce73376073ae2e1ad3c00d30e477a3ca7->leave($__internal_abc5370f82133baead9c396dff6dde8ce73376073ae2e1ad3c00d30e477a3ca7_prof);

    }

    // line 25
    public function block_LeftColumn($context, array $blocks = array())
    {
        $__internal_5cb5591a70dda7704fa621295020cc639a223a41699a2cffe2715c4735083995 = $this->env->getExtension("native_profiler");
        $__internal_5cb5591a70dda7704fa621295020cc639a223a41699a2cffe2715c4735083995->enter($__internal_5cb5591a70dda7704fa621295020cc639a223a41699a2cffe2715c4735083995_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "LeftColumn"));

        // line 26
        echo "    Porfavor, seleccione alguna de las opciones presentadas en la parte superior.
    <link href=\"http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css\" rel=\"stylesheet\">
";
        
        $__internal_5cb5591a70dda7704fa621295020cc639a223a41699a2cffe2715c4735083995->leave($__internal_5cb5591a70dda7704fa621295020cc639a223a41699a2cffe2715c4735083995_prof);

    }

    // line 30
    public function block_btn1href($context, array $blocks = array())
    {
        $__internal_71a2ac37d63d1287202fd5854bfab3b321f5091c326158de4b141b04bc97d26a = $this->env->getExtension("native_profiler");
        $__internal_71a2ac37d63d1287202fd5854bfab3b321f5091c326158de4b141b04bc97d26a->enter($__internal_71a2ac37d63d1287202fd5854bfab3b321f5091c326158de4b141b04bc97d26a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1href"));

        // line 31
        echo "    /ListaExamenes
";
        
        $__internal_71a2ac37d63d1287202fd5854bfab3b321f5091c326158de4b141b04bc97d26a->leave($__internal_71a2ac37d63d1287202fd5854bfab3b321f5091c326158de4b141b04bc97d26a_prof);

    }

    // line 33
    public function block_btn1($context, array $blocks = array())
    {
        $__internal_f2820e94e2f9bea50eaf1fa59ecacac50e79b3b48c765518697ce04c23e34d52 = $this->env->getExtension("native_profiler");
        $__internal_f2820e94e2f9bea50eaf1fa59ecacac50e79b3b48c765518697ce04c23e34d52->enter($__internal_f2820e94e2f9bea50eaf1fa59ecacac50e79b3b48c765518697ce04c23e34d52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn1"));

        echo "Examenes Creados
";
        
        $__internal_f2820e94e2f9bea50eaf1fa59ecacac50e79b3b48c765518697ce04c23e34d52->leave($__internal_f2820e94e2f9bea50eaf1fa59ecacac50e79b3b48c765518697ce04c23e34d52_prof);

    }

    // line 36
    public function block_btn2href($context, array $blocks = array())
    {
        $__internal_9e818d027372ef85510f9eb66cd9107fd38be18fd007d326cadb7d11ffd41715 = $this->env->getExtension("native_profiler");
        $__internal_9e818d027372ef85510f9eb66cd9107fd38be18fd007d326cadb7d11ffd41715->enter($__internal_9e818d027372ef85510f9eb66cd9107fd38be18fd007d326cadb7d11ffd41715_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2href"));

        // line 37
        echo "    /createExam
";
        
        $__internal_9e818d027372ef85510f9eb66cd9107fd38be18fd007d326cadb7d11ffd41715->leave($__internal_9e818d027372ef85510f9eb66cd9107fd38be18fd007d326cadb7d11ffd41715_prof);

    }

    // line 39
    public function block_btn2($context, array $blocks = array())
    {
        $__internal_551be91410ff2bf3919e4e85f7cd2618c8995fc2e2263fb983fe0fc55e8d9a23 = $this->env->getExtension("native_profiler");
        $__internal_551be91410ff2bf3919e4e85f7cd2618c8995fc2e2263fb983fe0fc55e8d9a23->enter($__internal_551be91410ff2bf3919e4e85f7cd2618c8995fc2e2263fb983fe0fc55e8d9a23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn2"));

        // line 40
        echo "    Crear Examen";
        
        $__internal_551be91410ff2bf3919e4e85f7cd2618c8995fc2e2263fb983fe0fc55e8d9a23->leave($__internal_551be91410ff2bf3919e4e85f7cd2618c8995fc2e2263fb983fe0fc55e8d9a23_prof);

    }

    // line 42
    public function block_btn3href($context, array $blocks = array())
    {
        $__internal_44f24212f18dc254b9aed14ef2a3cef0104ec779b52bca47f89b0677dbcea386 = $this->env->getExtension("native_profiler");
        $__internal_44f24212f18dc254b9aed14ef2a3cef0104ec779b52bca47f89b0677dbcea386->enter($__internal_44f24212f18dc254b9aed14ef2a3cef0104ec779b52bca47f89b0677dbcea386_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn3href"));

        
        $__internal_44f24212f18dc254b9aed14ef2a3cef0104ec779b52bca47f89b0677dbcea386->leave($__internal_44f24212f18dc254b9aed14ef2a3cef0104ec779b52bca47f89b0677dbcea386_prof);

    }

    // line 43
    public function block_btn3($context, array $blocks = array())
    {
        $__internal_1210c395b2b3395eae498739a98672b91d9bf668c6c83087e5f686fb3aec509f = $this->env->getExtension("native_profiler");
        $__internal_1210c395b2b3395eae498739a98672b91d9bf668c6c83087e5f686fb3aec509f->enter($__internal_1210c395b2b3395eae498739a98672b91d9bf668c6c83087e5f686fb3aec509f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "btn3"));

        echo "Añadir Estudiante
";
        
        $__internal_1210c395b2b3395eae498739a98672b91d9bf668c6c83087e5f686fb3aec509f->leave($__internal_1210c395b2b3395eae498739a98672b91d9bf668c6c83087e5f686fb3aec509f_prof);

    }

    // line 45
    public function block_subtitle($context, array $blocks = array())
    {
        $__internal_f0a8266fed234d4324496ccfefbda57bff2d98a7574c3124d6c0123dc3f7b816 = $this->env->getExtension("native_profiler");
        $__internal_f0a8266fed234d4324496ccfefbda57bff2d98a7574c3124d6c0123dc3f7b816->enter($__internal_f0a8266fed234d4324496ccfefbda57bff2d98a7574c3124d6c0123dc3f7b816_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subtitle"));

        
        $__internal_f0a8266fed234d4324496ccfefbda57bff2d98a7574c3124d6c0123dc3f7b816->leave($__internal_f0a8266fed234d4324496ccfefbda57bff2d98a7574c3124d6c0123dc3f7b816_prof);

    }

    // line 47
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ab4de535803af4a186d50094af731076edce19fea4c4dba3a72e8cd529d49c7f = $this->env->getExtension("native_profiler");
        $__internal_ab4de535803af4a186d50094af731076edce19fea4c4dba3a72e8cd529d49c7f->enter($__internal_ab4de535803af4a186d50094af731076edce19fea4c4dba3a72e8cd529d49c7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 48
        echo "    <style>
        .log-in-form {
            border: 1px solid #cacaca;
            padding: 1rem;
            border-radius: 3px;
        }
        .header {
            text-align: center;
            background: #000000;
            background-size: cover;
            padding: 4rem;
        }
        .header .main-header {
            color: #666;
        }

        .header-subnav {
            float: none;
            position: relative;
            top: 4rem;
            text-align: center;
            margin-bottom: 0;
        }
        .header-subnav li {
            float: none;
            display: inline-block;
        }
        .header-subnav li a {
            padding: 0.9rem 1rem 0.75rem;
            font-size: 0.875rem;
            color: #fff;
            text-transform: uppercase;
            display: block;
            font-weight: bold;
            letter-spacing: 1px;
        }
        .header-subnav li a.is-active {
            background: rgba(250, 250, 250, 0.7);
            color: #333;
        }
        .header-subnav li a:hover {
            background: rgba(250, 250, 250, 0.7);
            color: #333;
            transition: all 0.25s ease-in-out;
        }

    </style>
";
        
        $__internal_ab4de535803af4a186d50094af731076edce19fea4c4dba3a72e8cd529d49c7f->leave($__internal_ab4de535803af4a186d50094af731076edce19fea4c4dba3a72e8cd529d49c7f_prof);

    }

    public function getTemplateName()
    {
        return "eva/docente.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 48,  251 => 47,  240 => 45,  227 => 43,  216 => 42,  209 => 40,  203 => 39,  195 => 37,  189 => 36,  176 => 33,  168 => 31,  162 => 30,  153 => 26,  147 => 25,  138 => 22,  132 => 21,  122 => 17,  116 => 16,  106 => 12,  100 => 11,  90 => 7,  84 => 6,  73 => 4,  61 => 3,  49 => 2,  11 => 1,);
    }
}
/* {% extends 'evabase.html.twig' %}*/
/* {% block title %}Docente{% endblock %}{#Titulo barra navegador#}*/
/* {% block titulo %}{{parent()}}{% endblock %}{#Titulo interno página#}*/
/* {% block field %}{% endblock %}{#Primer Texto Columna Izq#}*/
/* {#  Adición de imagenes por campo en la plantilla #}*/
/* {% block field1 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field2 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field3 %}*/
/*     <div class="media-object-section">*/
/*         <img class="thumbnail" src="http://placehold.it/100">*/
/*     </div>*/
/* {% endblock %}*/
/* {% block field4 %}*/
/*     <img style="max-width:100px; max-height:100px;" class="thumbnail" src="https://upload.wikimedia.org/wikipedia/commons/3/35/Tux.svg">*/
/*     Linux*/
/* {% endblock %}*/
/* {% block LeftColumn %}*/
/*     Porfavor, seleccione alguna de las opciones presentadas en la parte superior.*/
/*     <link href="http://cdnjs.cloudflare.com/ajax/libs/foundicons/3.0.0/foundation-icons.css" rel="stylesheet">*/
/* {% endblock %}*/
/* */
/* {% block btn1href %}*/
/*     /ListaExamenes*/
/* {% endblock %}*/
/* {% block btn1 %}Examenes Creados*/
/* {% endblock %}*/
/* */
/* {% block btn2href %}*/
/*     /createExam*/
/* {% endblock %}*/
/* {% block btn2 %}*/
/*     Crear Examen{% endblock %}*/
/* */
/* {% block btn3href %}{% endblock %}*/
/* {% block btn3 %}Añadir Estudiante*/
/* {% endblock %}*/
/* {% block subtitle %}{% endblock %}*/
/* */
/* {% block stylesheets %}*/
/*     <style>*/
/*         .log-in-form {*/
/*             border: 1px solid #cacaca;*/
/*             padding: 1rem;*/
/*             border-radius: 3px;*/
/*         }*/
/*         .header {*/
/*             text-align: center;*/
/*             background: #000000;*/
/*             background-size: cover;*/
/*             padding: 4rem;*/
/*         }*/
/*         .header .main-header {*/
/*             color: #666;*/
/*         }*/
/* */
/*         .header-subnav {*/
/*             float: none;*/
/*             position: relative;*/
/*             top: 4rem;*/
/*             text-align: center;*/
/*             margin-bottom: 0;*/
/*         }*/
/*         .header-subnav li {*/
/*             float: none;*/
/*             display: inline-block;*/
/*         }*/
/*         .header-subnav li a {*/
/*             padding: 0.9rem 1rem 0.75rem;*/
/*             font-size: 0.875rem;*/
/*             color: #fff;*/
/*             text-transform: uppercase;*/
/*             display: block;*/
/*             font-weight: bold;*/
/*             letter-spacing: 1px;*/
/*         }*/
/*         .header-subnav li a.is-active {*/
/*             background: rgba(250, 250, 250, 0.7);*/
/*             color: #333;*/
/*         }*/
/*         .header-subnav li a:hover {*/
/*             background: rgba(250, 250, 250, 0.7);*/
/*             color: #333;*/
/*             transition: all 0.25s ease-in-out;*/
/*         }*/
/* */
/*     </style>*/
/* {% endblock %}*/
/* */
